import { Link, useLocation } from "@tanstack/react-router";
import { Home, BarChart3, ScanLine, Pill, User } from "lucide-react";

type NavItem = { to: string; label: string; icon: typeof Home };
const items: NavItem[] = [
  { to: "/today", label: "Today", icon: Home },
  { to: "/history", label: "Insights", icon: BarChart3 },
  { to: "/scan", label: "Scan", icon: ScanLine },
  { to: "/meds", label: "Meds", icon: Pill },
  { to: "/profile", label: "You", icon: User },
];

export function BottomNav() {
  const { pathname } = useLocation();
  const activeIdx = items.findIndex(
    (i) => pathname === i.to || (i.to !== "/today" && pathname.startsWith(i.to)),
  );

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 pb-[env(safe-area-inset-bottom)] pointer-events-none">
      <div className="mx-auto max-w-md px-4 pb-3 pointer-events-auto">
        <ul
          className="relative flex items-stretch justify-around rounded-2xl border border-white/40 dark:border-white/10 bg-card/85 backdrop-blur-2xl p-1.5"
          style={{ boxShadow: "var(--shadow-lift)" }}
        >
          {items.map((item, i) => {
            const active = i === activeIdx;
            const { to, label, icon: Icon } = item;
            return (
              <li key={to} className="flex-1 relative">
                <Link
                  to={to as any}
                  className={`relative group flex flex-col items-center justify-center pt-2 pb-1.5 rounded-xl text-[10px] font-bold transition-colors duration-150 ${
                    active ? "text-primary-foreground" : "text-muted-foreground"
                  }`}
                >
                  {/* Circle bubble behind icon only */}
                  <span
                    aria-hidden
                    className={`absolute top-1 size-10 rounded-full transition-all duration-200 ease-out ${
                      active ? "scale-100 opacity-100" : "scale-50 opacity-0"
                    }`}
                    style={{
                      background: "var(--primary)",
                      boxShadow: active ? "var(--shadow-soft)" : "none",
                    }}
                  />
                  <Icon
                    className={`size-[19px] relative transition-transform duration-150 ${
                      active ? "scale-110" : "group-active:scale-90"
                    }`}
                    strokeWidth={active ? 2.6 : 2}
                  />
                  <span className={`mt-1 relative transition-colors ${active ? "text-foreground" : ""}`}>{label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
