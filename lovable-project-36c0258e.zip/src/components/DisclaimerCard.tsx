import { Info, X } from "lucide-react";
import { useDisclaimerDismissed } from "@/lib/disclaimer";

export function DisclaimerCard({
  compact = false,
  dismissible = true,
  variant = "soft",
  text,
}: {
  compact?: boolean;
  dismissible?: boolean;
  variant?: "soft" | "strong";
  text?: string;
}) {
  const { dismissed, dismiss } = useDisclaimerDismissed();
  if (dismissible && dismissed) return null;

  const message =
    text ??
    "MediMind provides reminders and general drug info only. Always check your Rx label and consult your doctor.";

  const tone =
    variant === "strong"
      ? "border-warning/40 bg-warning/15"
      : "border-border/60 bg-muted/40";

  return (
    <div className={`relative rounded-xl border ${tone} ${compact ? "p-2.5" : "p-3"}`}>
      <div className="flex gap-2 pr-6">
        <Info className={`shrink-0 ${compact ? "size-3.5 mt-0.5" : "size-4 mt-0.5"} text-warning`} />
        <p className={`leading-snug text-muted-foreground ${compact ? "text-[11px]" : "text-xs"}`}>
          {message}
        </p>
      </div>
      {dismissible && (
        <button
          onClick={dismiss}
          aria-label="Don't show again"
          className="absolute top-1.5 right-1.5 p-1 rounded-md text-muted-foreground hover:bg-muted/60"
          title="Don't show again"
        >
          <X className="size-3" />
        </button>
      )}
    </div>
  );
}

export function ReviewDisclaimer() {
  return (
    <div className="rounded-xl border border-warning/40 bg-warning/10 p-3">
      <p className="text-xs text-warning-foreground leading-snug">
        <span className="font-semibold">Please review carefully.</span> AI may misread handwriting.
        Make sure every medicine, dose, and time matches your prescription — edit any field that's wrong.
      </p>
    </div>
  );
}
