import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Watch, Smartphone, Bell, BellOff, Plus, Trash2, Check, Volume2, VolumeX, Vibrate, Activity } from "lucide-react";
import {
  notifPermission, requestNotif, showTest, getDevices, addDevice, removeDevice,
  getSound, setSound, type PairedDevice,
} from "@/lib/notifications";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/devices")({ component: Devices });

function Devices() {
  const navigate = useNavigate();
  const [perm, setPerm] = useState<NotificationPermission>("default");
  const [devices, setDevices] = useState<PairedDevice[]>([]);
  const [sound, setSoundState] = useState(true);
  const [addOpen, setAddOpen] = useState(false);

  useEffect(() => {
    setPerm(notifPermission());
    setDevices(getDevices());
    setSoundState(getSound());
  }, []);

  async function enable() {
    const ok = await requestNotif();
    setPerm(notifPermission());
    if (ok) toast.success("Notifications enabled — your watch will buzz too if paired with your phone.");
    else toast.error("Permission denied. Enable notifications in your browser settings.");
  }

  function pair(type: PairedDevice["type"], name: string) {
    const d = addDevice({ type, name });
    setDevices(getDevices());
    setAddOpen(false);
    toast.success(`${d.name} paired`);
  }

  function unpair(id: string) {
    removeDevice(id);
    setDevices(getDevices());
    toast.success("Device removed");
  }

  return (
    <div className="px-5 pt-6 pb-4">
      <button onClick={() => navigate({ to: "/profile" })} className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4">
        <ArrowLeft className="size-4" /> Back
      </button>

      <h1 className="text-3xl font-bold tracking-tight font-display">Devices</h1>
      <p className="text-sm text-muted-foreground mt-1">Get reminders on your phone and wrist.</p>

      {/* Notifications hero */}
      <div className="mt-5 rounded-3xl p-5 text-white relative overflow-hidden" style={{ background: "var(--gradient-sunrise)", boxShadow: "var(--shadow-lift)" }}>
        <div className="absolute -right-8 -top-8 size-40 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex items-center gap-4">
          <div className="size-14 rounded-2xl bg-white/25 backdrop-blur flex items-center justify-center">
            {perm === "granted" ? <Bell className="size-7" /> : <BellOff className="size-7" />}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs uppercase tracking-wider opacity-90 font-semibold">Notifications</p>
            <p className="text-xl font-bold font-display">{perm === "granted" ? "Enabled" : "Off"}</p>
            <p className="text-xs opacity-90">
              {perm === "granted" ? "Reminders mirror to your paired watch." : "Turn on to never miss a dose."}
            </p>
          </div>
        </div>
        <div className="flex gap-2 mt-4">
          {perm !== "granted" ? (
            <button onClick={enable} className="flex-1 h-11 rounded-xl bg-white text-foreground font-semibold text-sm">
              Enable notifications
            </button>
          ) : (
            <button onClick={() => showTest()} className="flex-1 h-11 rounded-xl bg-white/20 backdrop-blur text-white font-semibold text-sm">
              Send test
            </button>
          )}
        </div>
      </div>

      {/* Settings */}
      <div className="mt-4 rounded-3xl bg-card border border-border" style={{ boxShadow: "var(--shadow-soft)" }}>
        <Toggle
          icon={sound ? Volume2 : VolumeX}
          title="Notification sound"
          subtitle="Play sound with each reminder"
          value={sound}
          onChange={(v) => { setSound(v); setSoundState(v); }}
        />
        <Divider />
        <Toggle
          icon={Vibrate}
          title="Vibration"
          subtitle="Buzz on phone and paired watch"
          value={true}
          onChange={() => toast.info("Vibration follows your device settings")}
        />
      </div>

      {/* Paired devices */}
      <div className="mt-5 flex items-baseline justify-between">
        <h2 className="text-lg font-bold font-display">Paired devices</h2>
        <button onClick={() => setAddOpen(true)} className="text-sm text-primary font-semibold flex items-center gap-1">
          <Plus className="size-4" /> Add
        </button>
      </div>

      {devices.length === 0 ? (
        <div className="mt-3 rounded-3xl border border-dashed border-border p-8 text-center">
          <div className="size-12 rounded-2xl bg-accent mx-auto flex items-center justify-center mb-3 animate-float">
            <Watch className="size-6 text-primary" />
          </div>
          <p className="font-semibold">No devices paired</p>
          <p className="text-sm text-muted-foreground mt-1">Connect a smartwatch to get gentle wrist taps.</p>
          <button onClick={() => setAddOpen(true)} className="mt-4 h-10 px-4 rounded-xl bg-primary text-primary-foreground text-sm font-semibold inline-flex items-center gap-1.5">
            <Plus className="size-4" /> Pair device
          </button>
        </div>
      ) : (
        <ul className="mt-3 space-y-2">
          {devices.map((d) => (
            <li key={d.id} className="rounded-2xl bg-card border border-border p-3 flex items-center gap-3" style={{ boxShadow: "var(--shadow-soft)" }}>
              <div className="size-11 rounded-xl bg-primary/15 flex items-center justify-center">
                {d.type === "phone" ? <Smartphone className="size-5 text-primary" /> :
                 d.type === "fitbit" ? <Activity className="size-5 text-primary" /> :
                 <Watch className="size-5 text-primary" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{d.name}</p>
                <p className="text-xs text-success flex items-center gap-1">
                  <span className="size-1.5 rounded-full bg-success animate-pulse" /> Connected
                </p>
              </div>
              <button onClick={() => unpair(d.id)} className="size-9 rounded-xl text-coral hover:bg-coral/10 flex items-center justify-center">
                <Trash2 className="size-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* Pairing instructions */}
      <div className="mt-6 rounded-2xl border border-border bg-card p-4" style={{ boxShadow: "var(--shadow-soft)" }}>
        <h2 className="text-sm font-bold font-display flex items-center gap-2">
          <Watch className="size-4 text-primary" /> How pairing works
        </h2>
        <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
          MediMind uses your phone's web notifications. When your watch is paired with the same phone, every reminder mirrors to your wrist automatically — no separate app required.
        </p>
        <div className="mt-3 space-y-3 text-xs">
          <Howto
            title="Apple Watch"
            steps={[
              "On iPhone: Settings → Notifications → Safari → Allow Notifications.",
              "Open the Watch app → Notifications → Mirror iPhone Alerts From: turn on Safari.",
              "Back in MediMind, tap Enable notifications and Send test — your watch should buzz.",
            ]}
          />
          <Howto
            title="Wear OS (Pixel Watch, Galaxy Watch)"
            steps={[
              "On Android: Settings → Apps → Chrome → Notifications → Allow.",
              "Open the Galaxy Wearable / Watch app → Notifications → enable mirroring for Chrome.",
              "Tap Enable notifications and Send test here in MediMind.",
            ]}
          />
          <Howto
            title="Fitbit"
            steps={[
              "In the Fitbit app: Devices → your watch → Notifications → App Notifications → enable Chrome / Safari.",
              "Make sure your phone is unlocked when reminders fire; Fitbit only mirrors when active.",
              "Pair below and tap Send test to confirm.",
            ]}
          />
        </div>
      </div>

      <p className="text-xs text-muted-foreground text-center mt-6 px-6">
        Reminders are delivered as web notifications and mirror to your watch when paired with this phone.
      </p>

      {/* Add device sheet */}
      {addOpen && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setAddOpen(false)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div className="relative w-full bg-card rounded-t-3xl p-5 pb-8 max-w-md mx-auto" onClick={(e) => e.stopPropagation()}>
            <div className="size-10 h-1 rounded-full bg-muted mx-auto mb-4" />
            <h3 className="text-xl font-bold font-display">Pair a device</h3>
            <p className="text-sm text-muted-foreground mt-1">Pick what you want to add.</p>
            <div className="grid grid-cols-2 gap-2 mt-4">
              <PairBtn icon={Watch} label="Apple Watch" onClick={() => pair("apple-watch", "Apple Watch")} />
              <PairBtn icon={Watch} label="Wear OS" onClick={() => pair("wear-os", "Wear OS Watch")} />
              <PairBtn icon={Activity} label="Fitbit" onClick={() => pair("fitbit", "Fitbit")} />
              <PairBtn icon={Smartphone} label="This phone" onClick={() => pair("phone", "This phone")} />
            </div>
            <p className="text-[11px] text-muted-foreground mt-3 text-center">
              Pairing saves the device to your profile. Actual sync uses your phone's notification mirroring.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function Toggle({ icon: Icon, title, subtitle, value, onChange }: { icon: any; title: string; subtitle: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)} className="w-full p-4 flex items-center gap-3 text-left">
      <div className="size-10 rounded-xl bg-accent flex items-center justify-center">
        <Icon className="size-5 text-primary" />
      </div>
      <div className="flex-1">
        <p className="font-semibold text-sm">{title}</p>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </div>
      <div className={`w-11 h-6 rounded-full p-0.5 transition-colors ${value ? "bg-primary" : "bg-muted"}`}>
        <div className={`size-5 rounded-full bg-white shadow-sm transition-transform ${value ? "translate-x-5" : ""}`} />
      </div>
    </button>
  );
}

function Divider() { return <div className="h-px bg-border mx-4" />; }

function PairBtn({ icon: Icon, label, onClick }: { icon: any; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="h-24 rounded-2xl border border-border bg-card flex flex-col items-center justify-center gap-1.5 hover:border-primary hover:bg-primary/5 transition-all">
      <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center">
        <Icon className="size-5 text-primary" />
      </div>
      <span className="text-xs font-semibold">{label}</span>
    </button>
  );
}

function Howto({ title, steps }: { title: string; steps: string[] }) {
  return (
    <details className="rounded-xl border border-border bg-background/50 px-3 py-2.5 group">
      <summary className="text-xs font-bold cursor-pointer list-none flex items-center justify-between">
        {title}
        <span className="text-muted-foreground group-open:rotate-180 transition-transform">▾</span>
      </summary>
      <ol className="mt-2 space-y-1.5 list-decimal list-inside text-muted-foreground leading-relaxed">
        {steps.map((s, i) => <li key={i}>{s}</li>)}
      </ol>
    </details>
  );
}
