import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import {
  ArrowLeft, Plus, Trash2, Loader2, Pill, Sun, Moon, Sunrise, Sunset, Utensils,
  Syringe, Droplet, Wind, FlaskConical, Package, Tablets, Leaf, Atom, MoreHorizontal,
} from "lucide-react";
import { toast } from "sonner";
import { to12h } from "@/lib/time";

export const Route = createFileRoute("/_authenticated/add")({ component: Add });

type Preset = { id: string; label: string; times: string[] };
const PRESETS: Preset[] = [
  { id: "qd", label: "Once daily", times: ["09:00"] },
  { id: "bid", label: "Twice daily", times: ["09:00", "21:00"] },
  { id: "tid", label: "3× daily", times: ["08:00", "14:00", "20:00"] },
  { id: "qid", label: "4× daily", times: ["06:00", "12:00", "18:00", "22:00"] },
  { id: "morn", label: "Morning only", times: ["08:00"] },
  { id: "night", label: "Bedtime", times: ["22:00"] },
];

const COLORS = ["#5dd5b4", "#ff8c66", "#fbbf24", "#a78bfa", "#60a5fa", "#f472b6"];

const FOOD_OPTIONS = [
  { id: "any", label: "Anytime" },
  { id: "with-food", label: "With food" },
  { id: "before-food", label: "Before food" },
  { id: "empty", label: "Empty stomach" },
];

const FORM_OPTIONS = [
  { id: "Pill", icon: Pill },
  { id: "Tablet", icon: Tablets },
  { id: "Capsule", icon: Pill },
  { id: "Injection", icon: Syringe },
  { id: "Peptide", icon: Atom },
  { id: "Supplement", icon: Leaf },
  { id: "Solution", icon: FlaskConical },
  { id: "Drops", icon: Droplet },
  { id: "Inhaler", icon: Wind },
  { id: "Powder", icon: Package },
  { id: "Other", icon: MoreHorizontal },
];

function Add() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [name, setName] = useState("");
  const [dosage, setDosage] = useState("");
  const [form, setForm] = useState("Pill");
  const [reason, setReason] = useState("");
  const [preset, setPreset] = useState<string>("qd");
  const [times, setTimes] = useState<string[]>(["09:00"]);
  const [instructions, setInstructions] = useState(""); // food/extra instructions only
  const [foodRule, setFoodRule] = useState("any");
  const [color, setColor] = useState(COLORS[0]);
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0, 10));
  const [endDate, setEndDate] = useState("");
  const [refillCount, setRefillCount] = useState<string>("");
  const [busy, setBusy] = useState(false);

  function applyPreset(p: Preset) {
    setPreset(p.id);
    setTimes(p.times);
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (!name.trim() || !dosage.trim()) {
      toast.error("Name and dosage are required");
      return;
    }
    setBusy(true);
    try {
      const food = FOOD_OPTIONS.find((f) => f.id === foodRule);
      const instructionParts = [
        food && food.id !== "any" ? food.label : null,
        refillCount ? `Refill at ${refillCount} left` : null,
      ].filter(Boolean);

      const { data, error } = await supabase.from("medicines").insert({
        user_id: user.id,
        name: name.trim(),
        dosage: dosage.trim(),
        times: times.filter(Boolean).sort(),
        instructions: instructionParts.join(" · ") || null,
        start_date: startDate,
        end_date: endDate || null,
        drug_key: name.trim().toLowerCase(),
        frequency_type: "daily",
        form,
        reason: reason.trim() || null,
        pill_color: color,
      } as any).select("id").single();
      if (error) throw error;
      toast.success("Reminder added 🎉");
      navigate({ to: "/medicine/$id", params: { id: data.id } });
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }

  const FormIcon = FORM_OPTIONS.find((f) => f.id === form)?.icon ?? Pill;

  return (
    <div className="px-5 pt-6 pb-4">
      <button onClick={() => navigate({ to: "/meds" })} className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4 active:scale-95 transition-transform">
        <ArrowLeft className="size-4" /> Back
      </button>

      {/* Live preview */}
      <div className="rounded-3xl p-5 text-white relative overflow-hidden mb-6"
        style={{ background: `linear-gradient(135deg, ${color}, ${color}cc)`, boxShadow: "var(--shadow-lift)" }}>
        <div className="absolute -right-8 -top-8 size-40 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex items-center gap-3">
          <div className="size-14 rounded-2xl bg-white/25 backdrop-blur flex items-center justify-center">
            <FormIcon className="size-7" />
          </div>
          <div className="min-w-0">
            <p className="text-xs uppercase tracking-wider opacity-90 font-semibold">New {form.toLowerCase()}</p>
            <p className="text-2xl font-bold font-display truncate">{name || "Medicine name"}</p>
            <p className="text-sm opacity-90">{dosage || "Dosage"} · {times.length} time{times.length > 1 ? "s" : ""}/day</p>
          </div>
        </div>
      </div>

      <form onSubmit={save} className="space-y-5">
        <Section title="Basics">
          <Input label="Medicine name" value={name} onChange={setName} required placeholder="e.g. Lisinopril" />
          <Input label="Dosage" value={dosage} onChange={setDosage} required placeholder="e.g. 10 mg, 1 tablet" />

          <div>
            <label className="text-sm font-semibold">Form</label>
            <div className="mt-2 overflow-x-auto -mx-1 px-1 scroll-smooth snap-x snap-mandatory">
              <div className="flex gap-2 w-max pb-1">
                {FORM_OPTIONS.map((f) => {
                  const Ic = f.icon;
                  const active = form === f.id;
                  return (
                    <button
                      key={f.id} type="button" onClick={() => setForm(f.id)}
                      className={`snap-start shrink-0 w-20 h-20 rounded-2xl flex flex-col items-center justify-center gap-1 border transition-all active:scale-95 ${
                        active ? "border-primary bg-primary/10 text-primary" : "border-border bg-card text-muted-foreground"
                      }`}
                    >
                      <Ic className="size-5" />
                      <span className="text-[11px] font-semibold">{f.id}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div>
            <label className="text-sm font-semibold">What's it for? <span className="text-muted-foreground font-normal text-xs">(optional)</span></label>
            <input
              value={reason} onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Blood pressure, anxiety, allergies"
              className="w-full mt-2 h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>

          <div>
            <label className="text-sm font-semibold">Pill color</label>
            <div className="flex gap-2 mt-2">
              {COLORS.map((c) => (
                <button key={c} type="button" onClick={() => setColor(c)}
                  className={`size-9 rounded-full transition-all ${color === c ? "ring-2 ring-offset-2 ring-foreground scale-110" : ""}`}
                  style={{ background: c }} aria-label={`Color ${c}`} />
              ))}
            </div>
          </div>
        </Section>

        <Section title="Schedule">
          <div>
            <label className="text-sm font-semibold">How often?</label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {PRESETS.map((p) => (
                <button key={p.id} type="button" onClick={() => applyPreset(p)}
                  className={`h-12 rounded-xl text-sm font-semibold border transition-all active:scale-95 ${
                    preset === p.id ? "border-primary bg-primary/10 text-primary" : "border-border bg-card text-foreground"
                  }`}>
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-sm font-semibold">Reminder times</label>
            <div className="mt-2 space-y-2">
              {times.map((t, i) => {
                const h = parseInt(t.split(":")[0]);
                const Ic = h < 6 ? Moon : h < 12 ? Sunrise : h < 17 ? Sun : h < 21 ? Sunset : Moon;
                return (
                  <div key={i} className="flex gap-2 items-center">
                    <div className="size-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <Ic className="size-5 text-primary" />
                    </div>
                    <input type="time" value={t}
                      onChange={(e) => { setPreset(""); setTimes((arr) => arr.map((x, j) => j === i ? e.target.value : x)); }}
                      className="flex-1 h-11 px-3 rounded-xl bg-background border border-input text-sm" />
                    <span className="text-xs text-muted-foreground w-16 text-right tabular-nums">{to12h(t)}</span>
                    {times.length > 1 && (
                      <button type="button" onClick={() => { setPreset(""); setTimes((arr) => arr.filter((_, j) => j !== i)); }}
                        className="size-11 rounded-xl border border-border flex items-center justify-center text-coral active:scale-95">
                        <Trash2 className="size-4" />
                      </button>
                    )}
                  </div>
                );
              })}
              <button type="button" onClick={() => { setPreset(""); setTimes((arr) => [...arr, "12:00"]); }}
                className="w-full h-10 rounded-xl border border-dashed border-border text-sm text-muted-foreground flex items-center justify-center gap-1.5 active:scale-95">
                <Plus className="size-4" /> Add another time
              </button>
            </div>
          </div>
        </Section>

        <Section title="Instructions">
          <div>
            <label className="text-sm font-semibold flex items-center gap-1.5"><Utensils className="size-4" /> Food</label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {FOOD_OPTIONS.map((f) => (
                <button key={f.id} type="button" onClick={() => setFoodRule(f.id)}
                  className={`h-10 rounded-xl text-sm font-medium border active:scale-95 ${
                    foodRule === f.id ? "border-primary bg-primary/10 text-primary" : "border-border bg-card"
                  }`}>
                  {f.label}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-muted-foreground mt-2">
              Personal notes live in <strong>Profile → Notes</strong>. Keep this clean and clinical.
            </p>
          </div>
        </Section>

        <Section title="Duration & refills">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground font-medium">Start</label>
              <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)}
                className="w-full mt-1 h-11 px-3 rounded-xl bg-background border border-input text-sm" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground font-medium">End <span className="opacity-60">(optional)</span></label>
              <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)}
                className="w-full mt-1 h-11 px-3 rounded-xl bg-background border border-input text-sm" />
            </div>
          </div>
          <div>
            <label className="text-sm font-semibold">Refill alert <span className="text-muted-foreground font-normal text-xs">(optional)</span></label>
            <div className="flex items-center gap-2 mt-2">
              <input type="number" min="0" value={refillCount} onChange={(e) => setRefillCount(e.target.value)}
                placeholder="5"
                className="w-24 h-11 px-3 rounded-xl bg-background border border-input text-sm" />
              <span className="text-sm text-muted-foreground">pills left → notify me</span>
            </div>
          </div>
        </Section>

        <button type="submit" disabled={busy}
          className="sticky bottom-24 w-full h-14 rounded-2xl text-primary-foreground font-semibold flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95 transition-transform"
          style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-lift)" }}>
          {busy && <Loader2 className="size-4 animate-spin" />} Save reminder
        </button>
      </form>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-3xl bg-card border border-border p-4 space-y-4" style={{ boxShadow: "var(--shadow-soft)" }}>
      <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{title}</h2>
      {children}
    </div>
  );
}

type InputProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value"> & {
  label: string; value: string; onChange: (v: string) => void;
};
function Input({ label, value, onChange, ...rest }: InputProps) {
  return (
    <div>
      <label className="text-sm font-semibold">{label}</label>
      <input value={value} onChange={(e) => onChange(e.target.value)} {...rest}
        className="w-full mt-2 h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
    </div>
  );
}
