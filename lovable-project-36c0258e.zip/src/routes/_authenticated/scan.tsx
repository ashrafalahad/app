import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { scanPrescription, identifyMedicine, getDrugInfo } from "@/lib/medicines.functions";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import {
  ArrowLeft, Camera, Loader2, Upload, Sparkles, Check, Type,
  FileText, PillBottle, Activity, AlertOctagon, Clock, Utensils, Baby, Pill,
  Trash2, X, History as HistoryIcon,
} from "lucide-react";
import { toast } from "sonner";
import { DisclaimerCard, ReviewDisclaimer } from "@/components/DisclaimerCard";
import { to12h } from "@/lib/time";
import { addScanHistory } from "@/lib/scanHistory";

export const Route = createFileRoute("/_authenticated/scan")({ component: Scan });

type Mode = "identify" | "rx" | "manual";
type Extracted = {
  name: string; dosage: string; frequency: string;
  duration: string; instructions: string; confidence: string;
  times: string[]; keep: boolean;
};
type Identified = {
  name: string; generic_name?: string; strength?: string; form?: string;
  what_for?: string; how_it_works?: string;
  common_side_effects?: string[]; serious_side_effects?: string[];
  interactions?: string[]; missed_dose?: string; pregnancy_warning?: string;
  confidence: "high" | "medium" | "low"; note?: string;
};

function Scan() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const cameraRef = useRef<HTMLInputElement>(null);
  const galleryRef = useRef<HTMLInputElement>(null);
  const scanRx = useServerFn(scanPrescription);
  const identify = useServerFn(identifyMedicine);
  const drugInfo = useServerFn(getDrugInfo);

  const [mode, setMode] = useState<Mode>("identify");
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<Extracted[] | null>(null);
  const [needsReview, setNeedsReview] = useState(false);
  const [identified, setIdentified] = useState<Identified | null>(null);
  const [manualQuery, setManualQuery] = useState("");
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  async function onFile(file: File) {
    if (file.size > 8 * 1024 * 1024) return toast.error("Image too large (max 8MB)");
    setBusy(true);
    setResults(null);
    setIdentified(null);
    try {
      const b64 = await fileToBase64(file);
      setPhotoPreview(b64);
      if (mode === "rx") {
        const result = await scanRx({ data: { imageBase64: b64 } });
        if (!result.medicines?.length) {
          toast.error("Couldn't read any medicines. Try a clearer photo or use Manual.");
          return;
        }
        const enriched = result.medicines.map((m) => ({
          ...m,
          name: m.name && m.name !== "Unknown" ? m.name : "",
          times: parseTimes(m.frequency),
          keep: true,
        }));
        setResults(enriched);
        setNeedsReview(result.needs_review || enriched.some((m) => !m.name));
        result.warnings?.forEach((w) => toast.warning(w));
        if (enriched.some((m) => !m.name)) toast.warning("Some medicine names were unclear — please fill them in.");
        addScanHistory({
          mode: "rx",
          name: `Prescription · ${enriched.length} med${enriched.length > 1 ? "s" : ""}`,
          summary: enriched.map((e) => e.name || "Unnamed").filter(Boolean).join(", ") || "Needs review",
          thumb: await makeThumb(b64),
          data: enriched,
        });
      } else if (mode === "identify") {
        const r = await identify({ data: { imageBase64: b64 } });
        if (!r?.name) return toast.error("Couldn't identify. Try a closer photo of the label.");
        setIdentified(r);
        if (r.confidence === "low") toast.warning("Low confidence — please verify with the label.");
        addScanHistory({
          mode: "identify",
          name: r.name,
          summary: [r.strength, r.form, r.generic_name].filter(Boolean).join(" · "),
          thumb: await makeThumb(b64),
          data: r,
        });
      }
    } catch (e: any) {
      toast.error(e.message ?? "Scan failed");
    } finally {
      setBusy(false);
    }
  }

  async function lookupManual() {
    const name = manualQuery.trim();
    if (!name) return toast.error("Type a medicine name");
    setBusy(true);
    setIdentified(null);
    try {
      const info = await drugInfo({ data: { name } });
      const r: Identified = {
        name: info.drug_name ?? name,
        what_for: info.what_for ?? undefined,
        how_it_works: info.how_it_works ?? undefined,
        common_side_effects: info.common_side_effects ?? [],
        serious_side_effects: info.serious_side_effects ?? [],
        interactions: info.interactions ?? [],
        missed_dose: info.missed_dose ?? undefined,
        pregnancy_warning: info.pregnancy_warning ?? undefined,
        confidence: "medium",
      };
      setIdentified(r);
      addScanHistory({
        mode: "manual",
        name: r.name,
        summary: [info.what_for].filter(Boolean).join(" · ").slice(0, 120),
        data: r,
      });
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function saveAll() {
    if (!user || !results) return;
    const toSave = results.filter((r) => r.keep);
    if (!toSave.length) return toast.error("Select at least one medicine to keep");
    if (toSave.some((r) => !r.name.trim())) return toast.error("All kept medicines need a name");
    setBusy(true);
    try {
      const rows = toSave.map((r) => ({
        user_id: user.id,
        name: r.name.trim(),
        dosage: r.dosage || "—",
        drug_key: r.name.trim().toLowerCase(),
        times: r.times.length ? r.times : ["09:00"],
        frequency_type: "daily",
        instructions: [r.frequency, r.duration, r.instructions].filter(Boolean).join(" · ") || null,
      }));
      const { data, error } = await supabase.from("medicines").insert(rows).select("id");
      if (error) throw error;
      toast.success(`${rows.length} reminder${rows.length > 1 ? "s" : ""} added 🎉`);
      const first = data?.[0]?.id;
      if (first) navigate({ to: "/medicine/$id", params: { id: first } });
      else navigate({ to: "/today" });
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function saveIdentified() {
    if (!user || !identified) return;
    setBusy(true);
    try {
      const { data, error } = await supabase.from("medicines").insert({
        user_id: user.id,
        name: identified.name,
        dosage: identified.strength || "—",
        drug_key: identified.name.trim().toLowerCase(),
        times: ["09:00"],
        frequency_type: "daily",
        instructions: identified.form ?? null,
        form: identified.form ?? null,
      } as any).select("id").single();
      if (error) throw error;
      toast.success("Saved to your meds");
      navigate({ to: "/medicine/$id", params: { id: data.id } });
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }

  function reset() {
    setResults(null);
    setIdentified(null);
    setNeedsReview(false);
    setManualQuery("");
    setPhotoPreview(null);
  }

  const hasResult = results || identified;

  return (
    <div className="px-5 pt-6">
      <button onClick={() => navigate({ to: "/today" })} className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4 active:scale-95 transition-transform">
        <ArrowLeft className="size-4" /> Back
      </button>

      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-2xl font-bold font-display tracking-tight">Scan & Look up</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {mode === "rx" ? "Snap a prescription — we'll set reminders for you." :
             mode === "identify" ? "Snap any pill, box or label — get full drug details." :
             "Type a name and learn what it does."}
          </p>
        </div>
        <button onClick={() => navigate({ to: "/scan-history" })}
          className="shrink-0 h-10 px-3 rounded-xl border border-border bg-card text-xs font-semibold flex items-center gap-1.5 active:scale-95">
          <HistoryIcon className="size-4" /> History
        </button>
      </div>

      {!hasResult && (
        <>
          {/* Mode tabs — 3 options */}
          <div className="mt-5 grid grid-cols-3 gap-1 p-1 rounded-2xl bg-muted/60 border border-border">
            <ModeTab active={mode === "identify"} onClick={() => { setMode("identify"); reset(); }} icon={PillBottle} label="Identify" />
            <ModeTab active={mode === "rx"} onClick={() => { setMode("rx"); reset(); }} icon={FileText} label="Rx" />
            <ModeTab active={mode === "manual"} onClick={() => { setMode("manual"); reset(); }} icon={Type} label="Manual" />
          </div>

          {mode === "manual" ? (
            <div className="mt-5 space-y-3">
              <div className="rounded-2xl border border-border bg-card p-5" style={{ boxShadow: "var(--shadow-soft)" }}>
                <label className="text-sm font-semibold">Medicine name</label>
                <input
                  value={manualQuery}
                  onChange={(e) => setManualQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && lookupManual()}
                  placeholder="e.g. Metformin, Atorvastatin"
                  className="w-full mt-2 h-12 px-3 rounded-xl bg-background border border-input text-base focus:outline-none focus:ring-2 focus:ring-ring"
                />
                <button
                  onClick={lookupManual} disabled={busy || !manualQuery.trim()}
                  className="w-full mt-3 h-12 rounded-xl text-primary-foreground font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95 transition-transform"
                  style={{ background: "var(--gradient-primary)" }}
                >
                  {busy ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
                  Look up details
                </button>
              </div>
              <DisclaimerCard compact />
            </div>
          ) : (
            <div className="mt-5 space-y-3">
              {/* Capture frame */}
              <div
                className="relative aspect-[4/3] rounded-3xl border-2 border-dashed border-border bg-card flex flex-col items-center justify-center text-muted-foreground overflow-hidden"
                style={!photoPreview ? { background: "var(--gradient-hero)" } : undefined}
              >
                {photoPreview && (
                  <img src={photoPreview} alt="Scan preview"
                    className="absolute inset-0 w-full h-full object-cover" />
                )}
                {busy ? (
                  <>
                    {photoPreview && <div className="absolute inset-0 bg-black/30 backdrop-blur-[1px]" />}
                    {/* Scanning sweep */}
                    <div className="absolute inset-x-0 top-0 h-full overflow-hidden pointer-events-none">
                      <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent animate-scan-sweep shadow-[0_0_18px_4px_var(--primary)]" />
                    </div>
                    <div className="absolute inset-4 rounded-2xl border-2 border-primary/60 animate-scan-pulse" />
                    {/* corner brackets */}
                    {["top-3 left-3 border-t-2 border-l-2","top-3 right-3 border-t-2 border-r-2","bottom-3 left-3 border-b-2 border-l-2","bottom-3 right-3 border-b-2 border-r-2"].map((c) => (
                      <div key={c} className={`absolute ${c} size-6 rounded-md border-primary`} />
                    ))}
                    <div className="relative flex flex-col items-center">
                      <div className="size-12 rounded-full bg-white/90 backdrop-blur flex items-center justify-center shadow-lg">
                        <Sparkles className="size-6 text-primary animate-pulse" />
                      </div>
                      <p className="mt-3 text-sm font-bold text-white drop-shadow">AI is reading your photo…</p>
                      <p className="text-[11px] text-white/90">This usually takes a few seconds</p>
                    </div>
                  </>
                ) : !photoPreview ? (
                  <>
                    <Camera className="size-10 text-primary" />
                    <p className="mt-3 text-sm font-medium text-foreground">
                      {mode === "rx" ? "Take a clear photo of your Rx" : "Center the medicine or label"}
                    </p>
                    <p className="text-xs">Make sure all text is readable</p>
                  </>
                ) : null}
              </div>

              <input
                ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); e.target.value = ""; }}
              />
              <input
                ref={galleryRef} type="file" accept="image/*" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); e.target.value = ""; }}
              />

              <button
                onClick={() => cameraRef.current?.click()} disabled={busy}
                className="w-full h-12 rounded-xl text-primary-foreground font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95 transition-transform"
                style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-soft)" }}
              >
                {busy ? <Loader2 className="size-4 animate-spin" /> : <Camera className="size-4" />}
                Take photo
              </button>
              <button
                onClick={() => galleryRef.current?.click()} disabled={busy}
                className="w-full h-12 rounded-xl border border-border bg-card font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95 transition-transform"
              >
                <Upload className="size-4" /> Upload from gallery
              </button>

              <DisclaimerCard compact />
            </div>
          )}
        </>
      )}

      {/* Rx results — editable */}
      {results && (
        <div className="mt-6 space-y-3 pb-4">
          <ReviewDisclaimer />
          {needsReview && (
            <div className="rounded-xl border border-warning/30 bg-warning/10 p-3 text-sm">
              Some fields look unclear — please double-check before saving.
            </div>
          )}
          <p className="text-sm text-muted-foreground">
            Found {results.length} medicine{results.length > 1 ? "s" : ""}. Toggle the ones you want to keep, edit anything, then save.
          </p>
          <ul className="space-y-2.5">
            {results.map((r, i) => (
              <li key={i}
                className={`rounded-2xl border p-4 transition-all ${
                  r.keep ? "bg-card border-border" : "bg-muted/40 border-muted opacity-60"
                }`}
                style={{ boxShadow: "var(--shadow-soft)" }}
              >
                <div className="flex items-start gap-2">
                  <button
                    type="button"
                    onClick={() => setResults((a) => a!.map((x, j) => j === i ? { ...x, keep: !x.keep } : x))}
                    className={`size-6 rounded-md border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                      r.keep ? "bg-primary border-primary text-primary-foreground" : "border-border bg-background"
                    }`}
                    aria-label={r.keep ? "Don't keep" : "Keep"}
                  >
                    {r.keep && <Check className="size-3.5" strokeWidth={3} />}
                  </button>
                  <input
                    value={r.name} placeholder="Medicine name"
                    onChange={(e) => setResults((arr) => arr!.map((x, j) => j === i ? { ...x, name: e.target.value } : x))}
                    className="flex-1 font-semibold bg-transparent focus:outline-none border-b border-transparent focus:border-primary"
                  />
                  <button
                    type="button"
                    onClick={() => setResults((a) => a!.filter((_, j) => j !== i))}
                    className="size-7 rounded-lg text-muted-foreground hover:text-coral flex items-center justify-center"
                    aria-label="Remove"
                  >
                    <X className="size-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-3">
                  <Field label="Dosage" value={r.dosage} onChange={(v) => setResults((a) => a!.map((x, j) => j === i ? { ...x, dosage: v } : x))} />
                  <Field label="Frequency" value={r.frequency} onChange={(v) => setResults((a) => a!.map((x, j) => j === i ? { ...x, frequency: v } : x))} />
                  <Field label="Duration" value={r.duration} onChange={(v) => setResults((a) => a!.map((x, j) => j === i ? { ...x, duration: v } : x))} />
                  <Field label="Instructions" value={r.instructions} onChange={(v) => setResults((a) => a!.map((x, j) => j === i ? { ...x, instructions: v } : x))} />
                </div>

                <div className="mt-3">
                  <p className="text-xs font-semibold text-muted-foreground mb-1.5">Reminder times</p>
                  <div className="flex flex-wrap gap-1.5">
                    {r.times.map((t, ti) => (
                      <div key={ti} className="flex items-center gap-1 rounded-lg bg-muted/60 px-1.5 py-1">
                        <input
                          type="time" value={t}
                          onChange={(e) => setResults((a) => a!.map((x, j) => j === i ? { ...x, times: x.times.map((tt, k) => k === ti ? e.target.value : tt) } : x))}
                          className="bg-transparent text-xs w-20 focus:outline-none"
                        />
                        <span className="text-[10px] text-muted-foreground tabular-nums">{to12h(t)}</span>
                        {r.times.length > 1 && (
                          <button type="button" onClick={() => setResults((a) => a!.map((x, j) => j === i ? { ...x, times: x.times.filter((_, k) => k !== ti) } : x))}
                            className="text-coral"><Trash2 className="size-3" /></button>
                        )}
                      </div>
                    ))}
                    <button type="button"
                      onClick={() => setResults((a) => a!.map((x, j) => j === i ? { ...x, times: [...x.times, "12:00"] } : x))}
                      className="rounded-lg border border-dashed border-border px-2 py-1 text-xs flex items-center gap-1 text-muted-foreground"
                    >
                      <span>+</span> Add time
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>

          <div className="flex gap-2 pt-2">
            <button onClick={reset} className="flex-1 h-11 rounded-xl border border-border bg-card text-sm font-semibold active:scale-95 transition-transform">
              Retry
            </button>
            <button onClick={saveAll} disabled={busy}
              className="flex-1 h-11 rounded-xl text-primary-foreground text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95 transition-transform"
              style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-soft)" }}>
              {busy ? <Loader2 className="size-4 animate-spin" /> : <Check className="size-4" />}
              Save {results.filter((r) => r.keep).length} reminder{results.filter((r) => r.keep).length === 1 ? "" : "s"}
            </button>
          </div>
        </div>
      )}

      {/* Identify / Manual results */}
      {identified && (
        <div className="mt-6 space-y-3 pb-4">
          <div className="rounded-2xl p-5 text-primary-foreground" style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-lift)" }}>
            <div className="flex items-center gap-2">
              <Pill className="size-5 opacity-90" />
              <span className="text-xs uppercase tracking-wide opacity-80">{mode === "manual" ? "Drug info" : "Identified"}</span>
              <span className={`ml-auto text-[10px] uppercase font-semibold tracking-wider px-2 py-0.5 rounded-full ${
                identified.confidence === "high" ? "bg-white/25" : identified.confidence === "medium" ? "bg-warning/40" : "bg-destructive/40"
              }`}>
                {identified.confidence}
              </span>
            </div>
            <h2 className="text-2xl font-bold mt-2 font-display">{identified.name}</h2>
            {identified.generic_name && <p className="opacity-90 text-sm">{identified.generic_name}</p>}
            <p className="opacity-90 mt-1 text-sm">
              {[identified.strength, identified.form].filter(Boolean).join(" · ")}
            </p>
          </div>

          {identified.note && (
            <div className="rounded-xl border border-warning/30 bg-warning/10 p-3 text-xs text-muted-foreground">
              {identified.note}
            </div>
          )}

          <InfoBlock icon={Activity} title="What it's for" body={identified.what_for} />
          <InfoBlock icon={Pill} title="How it works" body={identified.how_it_works} />
          <InfoList icon={AlertOctagon} title="Common side effects" tone="warning" items={identified.common_side_effects} />
          <InfoList icon={AlertOctagon} title="Serious side effects" tone="destructive" items={identified.serious_side_effects} />
          <InfoBlock icon={Clock} title="If you miss a dose" body={identified.missed_dose} />
          <InfoList icon={Utensils} title="Interactions" items={identified.interactions} />
          <InfoBlock icon={Baby} title="Pregnancy" body={identified.pregnancy_warning} />

          <div className="flex gap-2 pt-2">
            <button onClick={reset} className="flex-1 h-11 rounded-xl border border-border bg-card text-sm font-semibold active:scale-95">
              {mode === "manual" ? "Look up another" : "Scan another"}
            </button>
            <button onClick={saveIdentified} disabled={busy}
              className="flex-1 h-11 rounded-xl text-primary-foreground text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95"
              style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-soft)" }}>
              {busy ? <Loader2 className="size-4 animate-spin" /> : <Check className="size-4" />}
              Add to my meds
            </button>
          </div>

          <DisclaimerCard compact />
        </div>
      )}
    </div>
  );
}

function ModeTab({ active, onClick, icon: Icon, label }: { active: boolean; onClick: () => void; icon: any; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`h-10 rounded-xl text-sm font-semibold flex items-center justify-center gap-1.5 transition-all active:scale-95 ${
        active ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"
      }`}
    >
      <Icon className="size-4" /> {label}
    </button>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground">{label}</span>
      <input value={value ?? ""} onChange={(e) => onChange(e.target.value)}
        className="w-full mt-0.5 text-sm bg-transparent border-b border-border focus:outline-none focus:border-primary py-1" />
    </label>
  );
}

function InfoBlock({ icon: Icon, title, body }: { icon: any; title: string; body?: string | null }) {
  if (!body) return null;
  return (
    <div className="rounded-xl bg-card border border-border p-4" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-center gap-2 text-sm font-semibold">
        <Icon className="size-4 text-primary" /> {title}
      </div>
      <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{body}</p>
    </div>
  );
}

function InfoList({ icon: Icon, title, items, tone }: { icon: any; title: string; items?: string[]; tone?: "warning" | "destructive" }) {
  if (!items?.length) return null;
  const color = tone === "destructive" ? "text-destructive" : tone === "warning" ? "text-warning" : "text-primary";
  return (
    <div className="rounded-xl bg-card border border-border p-4" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-center gap-2 text-sm font-semibold">
        <Icon className={`size-4 ${color}`} /> {title}
      </div>
      <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
        {items.map((it, i) => <li key={i} className="flex gap-2"><span className="text-primary mt-1.5 size-1 rounded-full bg-primary shrink-0" />{it}</li>)}
      </ul>
    </div>
  );
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

// Build a small thumbnail to keep localStorage tiny.
async function makeThumb(dataUrl: string, max = 160): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const w = Math.round(img.width * scale);
      const h = Math.round(img.height * scale);
      const c = document.createElement("canvas");
      c.width = w; c.height = h;
      const ctx = c.getContext("2d");
      if (!ctx) return resolve(dataUrl);
      ctx.drawImage(img, 0, 0, w, h);
      try { resolve(c.toDataURL("image/jpeg", 0.6)); } catch { resolve(dataUrl); }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

function parseTimes(freq: string): string[] {
  const f = (freq || "").toLowerCase();
  if (/twice|2x|bid/.test(f)) return ["09:00", "21:00"];
  if (/three|3x|tid|every 8/.test(f)) return ["08:00", "14:00", "20:00"];
  if (/four|4x|qid|every 6/.test(f)) return ["06:00", "12:00", "18:00", "00:00"];
  if (/bedtime|qhs|night/.test(f)) return ["22:00"];
  return ["09:00"];
}
