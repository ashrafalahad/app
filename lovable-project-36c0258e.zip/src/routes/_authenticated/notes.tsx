import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useUserNotes, type UserNote } from "@/lib/userNotes";
import { ArrowLeft, Plus, Trash2, Pencil, X, Check, StickyNote } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/notes")({ component: Notes });

function Notes() {
  const navigate = useNavigate();
  const { items, save, remove } = useUserNotes();
  const [editing, setEditing] = useState<UserNote | null>(null);
  const [open, setOpen] = useState(false);

  return (
    <div className="px-5 pt-6 pb-4">
      <button onClick={() => navigate({ to: "/profile" })} className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4">
        <ArrowLeft className="size-4" /> Back
      </button>

      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight font-display">Notes</h1>
          <p className="text-sm text-muted-foreground mt-1">Personal medical notes — only on this device.</p>
        </div>
        <button onClick={() => { setEditing(null); setOpen(true); }}
          className="size-11 rounded-2xl text-white flex items-center justify-center active:scale-95"
          style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-soft)" }}>
          <Plus className="size-5" />
        </button>
      </div>

      {items.length === 0 ? (
        <div className="mt-8 rounded-3xl border border-dashed border-border p-8 text-center">
          <div className="size-12 rounded-2xl bg-accent mx-auto flex items-center justify-center mb-3 animate-float">
            <StickyNote className="size-6 text-primary" />
          </div>
          <p className="font-semibold">Nothing here yet</p>
          <p className="text-sm text-muted-foreground mt-1">Allergies, pharmacy hours, questions for your doctor — whatever you need.</p>
        </div>
      ) : (
        <ul className="mt-5 space-y-2">
          {items.map((n) => (
            <li key={n.id} className="rounded-2xl bg-card border border-border p-4" style={{ boxShadow: "var(--shadow-soft)" }}>
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-sm truncate">{n.title || "Untitled"}</p>
                  <p className="text-[11px] text-muted-foreground">{formatDistanceToNow(new Date(n.updatedAt), { addSuffix: true })}</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => { setEditing(n); setOpen(true); }} className="size-8 rounded-lg text-muted-foreground hover:text-primary flex items-center justify-center">
                    <Pencil className="size-4" />
                  </button>
                  <button onClick={() => remove(n.id)} className="size-8 rounded-lg text-muted-foreground hover:text-coral flex items-center justify-center">
                    <Trash2 className="size-4" />
                  </button>
                </div>
              </div>
              {n.body && <p className="text-sm text-muted-foreground mt-2 whitespace-pre-wrap">{n.body}</p>}
            </li>
          ))}
        </ul>
      )}

      {open && (
        <Editor initial={editing} onClose={() => setOpen(false)} onSave={(v) => {
          save({ id: editing?.id, ...v });
          setOpen(false);
          toast.success(editing ? "Saved" : "Note added");
        }} />
      )}
    </div>
  );
}

function Editor({ initial, onClose, onSave }: { initial: UserNote | null; onClose: () => void; onSave: (v: { title: string; body: string }) => void }) {
  const [title, setTitle] = useState(initial?.title ?? "");
  const [body, setBody] = useState(initial?.body ?? "");

  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
      <div className="relative w-full bg-card rounded-t-3xl p-5 pb-8 max-w-md mx-auto" onClick={(e) => e.stopPropagation()}>
        <div className="w-10 h-1 rounded-full bg-muted mx-auto mb-4" />
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xl font-bold font-display">{initial ? "Edit note" : "New note"}</h3>
          <button onClick={onClose} className="size-8 rounded-lg text-muted-foreground"><X className="size-4" /></button>
        </div>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title"
          className="w-full h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={6} placeholder="Write anything you want to remember…"
          className="w-full mt-3 px-3 py-2.5 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        <button onClick={() => onSave({ title, body })} className="mt-4 w-full h-12 rounded-xl text-white font-semibold flex items-center justify-center gap-2 active:scale-95"
          style={{ background: "var(--gradient-primary)" }}>
          <Check className="size-4" /> Save
        </button>
      </div>
    </div>
  );
}
