import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { startOfMonth, endOfMonth, eachDayOfInterval, format, isToday, isFuture, isSameDay, subDays } from "date-fns";
import { useMemo, useState } from "react";
import {
  ChevronLeft, ChevronRight, Check, X as XIcon, Clock, TrendingUp,
  ArrowRight, Flame, Sun, Sunrise, Sunset, Moon, Pill, Award,
} from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";

export const Route = createFileRoute("/_authenticated/history")({ component: History });

type LogRow = {
  scheduled_for: string; status: string; medicine_id: string;
  taken_at: string | null; skip_reason: string | null;
  medicines: { name: string; dosage: string } | null;
};

function History() {
  const [month, setMonth] = useState(() => startOfMonth(new Date()));
  const [selected, setSelected] = useState<Date | null>(null);
  const start = startOfMonth(month);
  const end = endOfMonth(month);

  const { data: logs } = useQuery({
    queryKey: ["history", format(month, "yyyy-MM")],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("adherence_logs")
        .select("scheduled_for,status,medicine_id,taken_at,skip_reason,medicines(name,dosage)")
        .gte("scheduled_for", start.toISOString())
        .lte("scheduled_for", end.toISOString())
        .order("scheduled_for");
      if (error) throw error;
      return data as unknown as LogRow[];
    },
  });

  // 30-day for trend
  const { data: trend } = useQuery({
    queryKey: ["trend-30"],
    queryFn: async () => {
      const from = subDays(new Date(), 29).toISOString();
      const { data, error } = await supabase
        .from("adherence_logs").select("scheduled_for,status,medicines(name)")
        .gte("scheduled_for", from);
      if (error) throw error;
      return data as unknown as { scheduled_for: string; status: string; medicines: { name: string } | null }[];
    },
  });

  const days = eachDayOfInterval({ start, end });

  const byDay = useMemo(() => {
    const m = new Map<string, { taken: number; skipped: number; logs: LogRow[] }>();
    logs?.forEach((l) => {
      const k = format(new Date(l.scheduled_for), "yyyy-MM-dd");
      const cur = m.get(k) ?? { taken: 0, skipped: 0, logs: [] };
      if (l.status === "taken") cur.taken++;
      else if (l.status === "skipped") cur.skipped++;
      cur.logs.push(l);
      m.set(k, cur);
    });
    return m;
  }, [logs]);

  const totals = useMemo(() => {
    let taken = 0, skipped = 0;
    byDay.forEach((v) => { taken += v.taken; skipped += v.skipped; });
    const total = taken + skipped;
    const rate = total ? Math.round((taken / total) * 100) : 0;
    return { taken, skipped, rate };
  }, [byDay]);

  // Time-of-day breakdown
  const timeOfDay = useMemo(() => {
    const buckets = { morning: { t: 0, s: 0 }, afternoon: { t: 0, s: 0 }, evening: { t: 0, s: 0 }, night: { t: 0, s: 0 } };
    trend?.forEach((l) => {
      const h = new Date(l.scheduled_for).getHours();
      const b = h < 12 ? "morning" : h < 17 ? "afternoon" : h < 21 ? "evening" : "night";
      if (l.status === "taken") buckets[b].t++;
      else if (l.status === "skipped") buckets[b].s++;
    });
    return buckets;
  }, [trend]);

  // 30-day streak
  const streak = useMemo(() => {
    const map = new Map<string, { t: number; s: number }>();
    trend?.forEach((l) => {
      const k = format(new Date(l.scheduled_for), "yyyy-MM-dd");
      const cur = map.get(k) ?? { t: 0, s: 0 };
      if (l.status === "taken") cur.t++;
      else if (l.status === "skipped") cur.s++;
      map.set(k, cur);
    });
    let s = 0;
    for (let i = 0; i < 60; i++) {
      const k = format(subDays(new Date(), i), "yyyy-MM-dd");
      const d = map.get(k);
      if (d && d.s === 0 && d.t > 0) s++;
      else if (d && d.s > 0) break;
      else if (i === 0) continue;
    }
    return s;
  }, [trend]);

  // Per-medicine adherence
  const perMed = useMemo(() => {
    const map = new Map<string, { name: string; t: number; total: number }>();
    trend?.forEach((l) => {
      const name = l.medicines?.name ?? "Unknown";
      const cur = map.get(name) ?? { name, t: 0, total: 0 };
      cur.total++;
      if (l.status === "taken") cur.t++;
      map.set(name, cur);
    });
    return Array.from(map.values())
      .filter((m) => m.total >= 1)
      .map((m) => ({ ...m, rate: Math.round((m.t / m.total) * 100) }))
      .sort((a, b) => b.rate - a.rate);
  }, [trend]);

  // 30-day daily bars
  const last30 = useMemo(() => {
    const map = new Map<string, { t: number; s: number }>();
    trend?.forEach((l) => {
      const k = format(new Date(l.scheduled_for), "yyyy-MM-dd");
      const cur = map.get(k) ?? { t: 0, s: 0 };
      if (l.status === "taken") cur.t++;
      else if (l.status === "skipped") cur.s++;
      map.set(k, cur);
    });
    return Array.from({ length: 30 }, (_, i) => {
      const k = format(subDays(new Date(), 29 - i), "yyyy-MM-dd");
      return { k, ...(map.get(k) ?? { t: 0, s: 0 }) };
    });
  }, [trend]);

  const selectedKey = selected ? format(selected, "yyyy-MM-dd") : null;
  const selectedData = selectedKey ? byDay.get(selectedKey) : null;

  return (
    <div className="px-5 pt-7 pb-4">
      <h1 className="text-3xl font-bold tracking-tight font-display">Insights</h1>
      <p className="text-sm text-muted-foreground mt-1">Your adherence story at a glance.</p>

      {/* Hero stat */}
      <div
        className="mt-5 rounded-3xl p-5 text-white relative overflow-hidden"
        style={{ background: "var(--gradient-sunrise)", boxShadow: "var(--shadow-lift)" }}
      >
        <div className="absolute -right-8 -top-8 size-40 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-wider opacity-90 font-semibold">This month</p>
            <p className="text-5xl font-bold mt-1 font-display tabular-nums">{totals.rate}%</p>
            <p className="text-sm opacity-90 mt-1">{totals.taken} of {totals.taken + totals.skipped} doses</p>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-1.5 justify-end">
              <Flame className="size-5" />
              <span className="text-2xl font-bold tabular-nums font-display">{streak}</span>
            </div>
            <p className="text-xs opacity-90">day streak</p>
          </div>
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-3 gap-2 mt-3">
        <Stat label="Taken" value={totals.taken} icon={Check} tone="success" />
        <Stat label="Missed" value={totals.skipped} icon={XIcon} tone="coral" />
        <Stat label="Best med" value={perMed[0]?.rate ?? 0} icon={Award} tone="primary" suffix="%" />
      </div>

      {/* 30-day trend */}
      <Section title="Last 30 days" subtitle="Doses taken vs missed">
        <div className="flex items-end justify-between gap-[2px] h-24">
          {last30.map(({ k, t, s }) => {
            const tot = t + s;
            const tPct = tot ? (t / Math.max(...last30.map((d) => d.t + d.s), 1)) * 100 : 0;
            const sPct = tot ? (s / Math.max(...last30.map((d) => d.t + d.s), 1)) * 100 : 0;
            return (
              <div key={k} className="flex-1 flex flex-col-reverse h-full">
                <div className="rounded-t-sm bg-coral" style={{ height: `${sPct}%` }} />
                <div className="rounded-t-sm" style={{ height: `${tPct}%`, background: "var(--gradient-primary)" }} />
              </div>
            );
          })}
        </div>
        <div className="flex gap-3 mt-2 text-[11px] text-muted-foreground">
          <Legend color="bg-primary" label="Taken" />
          <Legend color="bg-coral" label="Missed" />
        </div>
      </Section>

      {/* Time-of-day */}
      <Section title="Time of day" subtitle="When you take your meds">
        <div className="grid grid-cols-4 gap-2">
          <TimeCard icon={Sunrise} label="Morning" {...timeOfDay.morning} />
          <TimeCard icon={Sun} label="Afternoon" {...timeOfDay.afternoon} />
          <TimeCard icon={Sunset} label="Evening" {...timeOfDay.evening} />
          <TimeCard icon={Moon} label="Night" {...timeOfDay.night} />
        </div>
      </Section>

      {/* Per-medicine */}
      {perMed.length > 0 && (
        <Section title="By medicine" subtitle="Your most and least adherent">
          <ul className="space-y-2">
            {perMed.slice(0, 5).map((m) => (
              <li key={m.name} className="flex items-center gap-3">
                <div className="size-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Pill className="size-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline">
                    <p className="font-semibold text-sm truncate">{m.name}</p>
                    <span className="text-sm font-bold tabular-nums">{m.rate}%</span>
                  </div>
                  <div className="mt-1 h-1.5 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${m.rate}%`,
                        background: m.rate >= 80 ? "var(--gradient-primary)" : m.rate >= 50 ? "var(--warning)" : "var(--coral)",
                      }}
                    />
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {/* Calendar */}
      <Section
        title={format(month, "MMMM yyyy")}
        subtitle="Tap a day for details"
        action={
          <div className="flex gap-1">
            <button onClick={() => setMonth((m) => new Date(m.getFullYear(), m.getMonth() - 1, 1))} className="size-8 rounded-lg hover:bg-muted flex items-center justify-center">
              <ChevronLeft className="size-4" />
            </button>
            <button onClick={() => setMonth((m) => new Date(m.getFullYear(), m.getMonth() + 1, 1))} className="size-8 rounded-lg hover:bg-muted flex items-center justify-center">
              <ChevronRight className="size-4" />
            </button>
          </div>
        }
      >
        <div className="grid grid-cols-7 gap-1 text-center">
          {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
            <div key={i} className="text-[11px] font-semibold text-muted-foreground py-1">{d}</div>
          ))}
          {Array(days[0].getDay()).fill(null).map((_, i) => <div key={`pad-${i}`} />)}
          {days.map((d) => {
            const k = format(d, "yyyy-MM-dd");
            const stat = byDay.get(k);
            const future = isFuture(d) && !isToday(d);
            const isSel = selected && isSameDay(selected, d);

            let bg = "";
            let dot = "";
            if (stat) {
              if (stat.skipped === 0 && stat.taken > 0) { bg = "bg-success/15"; dot = "bg-success"; }
              else if (stat.taken > 0) { bg = "bg-warning/15"; dot = "bg-warning"; }
              else { bg = "bg-coral/15"; dot = "bg-coral"; }
            }

            return (
              <button
                key={k}
                onClick={() => !future && setSelected(d)}
                disabled={future}
                className={`aspect-square flex flex-col items-center justify-center text-sm rounded-xl transition-all relative ${
                  isToday(d) ? "ring-2 ring-primary font-bold" : ""
                } ${isSel ? "bg-primary text-primary-foreground" : bg} ${future ? "text-muted-foreground/40" : "hover:bg-muted"}`}
              >
                {format(d, "d")}
                {dot && !isSel && <span className={`absolute bottom-1 size-1.5 rounded-full ${dot}`} />}
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap gap-3 mt-4 pt-3 border-t border-border text-[11px] text-muted-foreground">
          <Legend color="bg-success" label="All taken" />
          <Legend color="bg-warning" label="Partial" />
          <Legend color="bg-coral" label="Missed" />
        </div>
      </Section>

      {/* Day detail sheet */}
      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent side="bottom" className="rounded-t-3xl max-h-[80vh] overflow-y-auto">
          <SheetHeader className="text-left">
            <SheetTitle className="font-display">{selected && format(selected, "EEEE, MMMM d")}</SheetTitle>
          </SheetHeader>
          {selectedData ? (
            <div className="mt-2 space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-2xl bg-success/10 border border-success/20 p-3">
                  <p className="text-xs text-muted-foreground">Taken</p>
                  <p className="text-2xl font-bold text-success font-display">{selectedData.taken}</p>
                </div>
                <div className="rounded-2xl bg-coral/10 border border-coral/20 p-3">
                  <p className="text-xs text-muted-foreground">Missed</p>
                  <p className="text-2xl font-bold text-coral font-display">{selectedData.skipped}</p>
                </div>
              </div>

              <ul className="space-y-2">
                {selectedData.logs
                  .sort((a, b) => a.scheduled_for.localeCompare(b.scheduled_for))
                  .map((l, i) => {
                    const taken = l.status === "taken";
                    const scheduled = format(new Date(l.scheduled_for), "HH:mm");
                    const actual = l.taken_at ? format(new Date(l.taken_at), "HH:mm") : null;
                    return (
                      <li key={i} className="rounded-2xl bg-card border border-border p-3">
                        <div className="flex items-start gap-3">
                          <div className={`size-10 rounded-xl flex items-center justify-center shrink-0 ${
                            taken ? "bg-success/15 text-success" : "bg-coral/15 text-coral"
                          }`}>
                            {taken ? <Check className="size-4" /> : <XIcon className="size-4" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-baseline gap-2">
                              <p className="font-semibold truncate">{l.medicines?.name ?? "Medicine"}</p>
                              <span className="text-xs text-muted-foreground">{l.medicines?.dosage}</span>
                            </div>
                            <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5">
                              <Clock className="size-3" />
                              <span>Scheduled {scheduled}</span>
                              {taken && actual && actual !== scheduled && (
                                <span>· Taken {actual}</span>
                              )}
                              {!taken && l.skip_reason && <span>· {l.skip_reason}</span>}
                            </div>
                          </div>
                          {l.medicine_id && (
                            <Link
                              to="/medicine/$id"
                              params={{ id: l.medicine_id }}
                              onClick={() => setSelected(null)}
                              className="text-muted-foreground"
                            >
                              <ArrowRight className="size-4" />
                            </Link>
                          )}
                        </div>
                      </li>
                    );
                  })}
              </ul>
            </div>
          ) : (
            <div className="py-10 text-center text-sm text-muted-foreground">
              No doses logged for this day.
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function Section({ title, subtitle, action, children }: { title: string; subtitle?: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="mt-5 rounded-3xl bg-card border border-border p-4" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-start justify-between mb-3">
        <div>
          <h2 className="font-bold font-display">{title}</h2>
          {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

function Stat({ label, value, icon: Icon, tone, suffix }: { label: string; value: number | string; icon: any; tone: "primary" | "success" | "coral"; suffix?: string }) {
  const colors: Record<string, string> = {
    primary: "text-primary bg-primary/10",
    success: "text-success bg-success/10",
    coral: "text-coral bg-coral/10",
  };
  return (
    <div className="rounded-2xl bg-card border border-border p-3" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className={`size-8 rounded-xl flex items-center justify-center mb-1.5 ${colors[tone]}`}>
        <Icon className="size-4" />
      </div>
      <p className="text-[11px] text-muted-foreground font-medium">{label}</p>
      <p className="text-xl font-bold leading-tight tabular-nums font-display">{value}{suffix}</p>
    </div>
  );
}

function TimeCard({ icon: Icon, label, t, s }: { icon: any; label: string; t: number; s: number }) {
  const total = t + s;
  const rate = total ? Math.round((t / total) * 100) : 0;
  return (
    <div className="rounded-2xl bg-muted/40 p-2.5 text-center">
      <Icon className="size-4 text-primary mx-auto" />
      <p className="text-[10px] text-muted-foreground mt-1 font-medium">{label}</p>
      <p className="text-base font-bold tabular-nums font-display mt-0.5">{rate}%</p>
      <p className="text-[10px] text-muted-foreground">{t}/{total}</p>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return <div className="flex items-center gap-1.5"><span className={`size-2 rounded-full ${color}`} />{label}</div>;
}
