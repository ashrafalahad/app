import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useAppointments, type Appointment } from "@/lib/appointments";
import { ArrowLeft, Plus, CalendarClock, MapPin, Trash2, Pencil, X, Check, Bell } from "lucide-react";
import { format, isPast, isToday, isTomorrow, differenceInDays } from "date-fns";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/appointments")({ component: Appointments });

function Appointments() {
  const navigate = useNavigate();
  const { items, add, update, remove } = useAppointments();
  const [editing, setEditing] = useState<Appointment | null>(null);
  const [open, setOpen] = useState(false);

  // In-app reminder for upcoming appointments
  useEffect(() => {
    const t = setInterval(() => {
      const now = Date.now();
      items.forEach((a) => {
        const t = new Date(a.at).getTime();
        const diff = t - now;
        if (!a.reminded && diff > 0 && diff < 24 * 60 * 60 * 1000) {
          if ("Notification" in window && Notification.permission === "granted") {
            new Notification("Upcoming appointment", {
              body: `Dr. ${a.doctor} · ${format(new Date(a.at), "EEE h:mm a")}`,
            });
          }
          update(a.id, { reminded: true });
        }
      });
    }, 60 * 1000);
    return () => clearInterval(t);
  }, [items, update]);

  const upcoming = items.filter((a) => !isPast(new Date(a.at)));
  const past = items.filter((a) => isPast(new Date(a.at)));

  return (
    <div className="px-5 pt-6 pb-4">
      <button onClick={() => navigate({ to: "/profile" })} className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4">
        <ArrowLeft className="size-4" /> Back
      </button>

      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight font-display">Appointments</h1>
          <p className="text-sm text-muted-foreground mt-1">We'll ping you the day before so nothing slips.</p>
        </div>
        <button
          onClick={() => { setEditing(null); setOpen(true); }}
          className="size-11 rounded-2xl text-white flex items-center justify-center active:scale-95"
          style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-soft)" }}
        >
          <Plus className="size-5" />
        </button>
      </div>

      {items.length === 0 && (
        <div className="mt-8 rounded-3xl border border-dashed border-border p-8 text-center">
          <div className="size-12 rounded-2xl bg-accent mx-auto flex items-center justify-center mb-3 animate-float">
            <CalendarClock className="size-6 text-primary" />
          </div>
          <p className="font-semibold">No appointments yet</p>
          <p className="text-sm text-muted-foreground mt-1">Tap + to add your next visit.</p>
        </div>
      )}

      {upcoming.length > 0 && (
        <>
          <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mt-6 mb-2 px-1">Upcoming</h2>
          <ul className="space-y-2">
            {upcoming.map((a) => (
              <AppointmentCard key={a.id} a={a} onEdit={() => { setEditing(a); setOpen(true); }} onDelete={() => remove(a.id)} />
            ))}
          </ul>
        </>
      )}

      {past.length > 0 && (
        <>
          <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mt-6 mb-2 px-1">Past</h2>
          <ul className="space-y-2 opacity-70">
            {past.slice(0, 10).map((a) => (
              <AppointmentCard key={a.id} a={a} onEdit={() => { setEditing(a); setOpen(true); }} onDelete={() => remove(a.id)} />
            ))}
          </ul>
        </>
      )}

      {open && (
        <Editor
          initial={editing}
          onClose={() => setOpen(false)}
          onSave={(v) => {
            if (editing) update(editing.id, { ...v, reminded: false });
            else add({ ...v, reminded: false });
            setOpen(false);
            toast.success(editing ? "Updated" : "Appointment saved · we'll remind you");
          }}
        />
      )}
    </div>
  );
}

function relative(d: Date): string {
  if (isToday(d)) return "Today";
  if (isTomorrow(d)) return "Tomorrow";
  const diff = differenceInDays(d, new Date());
  if (diff > 0 && diff < 7) return `In ${diff} days`;
  if (diff < 0) return format(d, "MMM d, yyyy");
  return format(d, "EEE, MMM d");
}

function AppointmentCard({ a, onEdit, onDelete }: { a: Appointment; onEdit: () => void; onDelete: () => void }) {
  const d = new Date(a.at);
  const upcoming = !isPast(d);
  return (
    <li className="rounded-2xl bg-card border border-border p-4" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-start gap-3">
        <div className={`size-12 rounded-xl flex flex-col items-center justify-center shrink-0 text-white ${upcoming ? "" : "bg-muted"}`}
          style={upcoming ? { background: "var(--gradient-primary)" } : {}}>
          <span className="text-[10px] font-bold uppercase opacity-90">{format(d, "MMM")}</span>
          <span className="text-base font-bold leading-none">{format(d, "d")}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-sm truncate">Dr. {a.doctor}</p>
          <p className="text-xs text-muted-foreground">
            {relative(d)} · {format(d, "h:mm a")}
          </p>
          {a.specialty && <p className="text-xs text-primary mt-0.5">{a.specialty}</p>}
          {a.location && (
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
              <MapPin className="size-3" /> {a.location}
            </p>
          )}
          {a.notes && <p className="text-xs text-muted-foreground mt-1.5">{a.notes}</p>}
        </div>
        <div className="flex flex-col gap-1">
          <button onClick={onEdit} className="size-8 rounded-lg text-muted-foreground hover:text-primary flex items-center justify-center">
            <Pencil className="size-4" />
          </button>
          <button onClick={onDelete} className="size-8 rounded-lg text-muted-foreground hover:text-coral flex items-center justify-center">
            <Trash2 className="size-4" />
          </button>
        </div>
      </div>
      {upcoming && (
        <p className="text-[11px] text-success flex items-center gap-1 mt-2">
          <Bell className="size-3" /> Reminder armed
        </p>
      )}
    </li>
  );
}

function Editor({ initial, onClose, onSave }: { initial: Appointment | null; onClose: () => void; onSave: (v: Omit<Appointment, "id">) => void }) {
  const [doctor, setDoctor] = useState(initial?.doctor ?? "");
  const [specialty, setSpecialty] = useState(initial?.specialty ?? "");
  const [location, setLocation] = useState(initial?.location ?? "");
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [at, setAt] = useState(initial?.at ?? new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().slice(0, 16));

  function submit() {
    if (!doctor.trim()) return toast.error("Doctor name required");
    if (!at) return toast.error("Pick a date and time");
    onSave({
      doctor: doctor.trim(),
      specialty: specialty.trim() || undefined,
      location: location.trim() || undefined,
      notes: notes.trim() || undefined,
      at: new Date(at).toISOString(),
    });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
      <div className="relative w-full bg-card rounded-t-3xl p-5 pb-8 max-w-md mx-auto" onClick={(e) => e.stopPropagation()}>
        <div className="w-10 h-1 rounded-full bg-muted mx-auto mb-4" />
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xl font-bold font-display">{initial ? "Edit appointment" : "New appointment"}</h3>
          <button onClick={onClose} className="size-8 rounded-lg text-muted-foreground"><X className="size-4" /></button>
        </div>
        <div className="space-y-3">
          <input value={doctor} onChange={(e) => setDoctor(e.target.value)} placeholder="Doctor's name"
            className="w-full h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          <input value={specialty} onChange={(e) => setSpecialty(e.target.value)} placeholder="Specialty (optional)"
            className="w-full h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          <input type="datetime-local" value={at.slice(0, 16)} onChange={(e) => setAt(e.target.value)}
            className="w-full h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Location / clinic (optional)"
            className="w-full h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Notes (optional)"
            className="w-full px-3 py-2.5 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <button onClick={submit} className="mt-4 w-full h-12 rounded-xl text-white font-semibold flex items-center justify-center gap-2 active:scale-95"
          style={{ background: "var(--gradient-primary)" }}>
          <Check className="size-4" /> {initial ? "Save changes" : "Add appointment"}
        </button>
      </div>
    </div>
  );
}
