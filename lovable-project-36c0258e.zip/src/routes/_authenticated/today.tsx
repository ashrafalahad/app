import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import {
  Plus, ScanLine, Check, X, ChevronRight, Flame,
  Clock, Sparkles, TrendingUp, Watch,
} from "lucide-react";
import { format, subDays, startOfDay } from "date-fns";
import { toast } from "sonner";
import { DisclaimerCard } from "@/components/DisclaimerCard";
import { useMemo, useState, useEffect } from "react";
import { to12hParts, to12h } from "@/lib/time";
import { iconForForm, DEFAULT_PILL_COLOR } from "@/lib/medForm";

export const Route = createFileRoute("/_authenticated/today")({ component: Today });

type Medicine = {
  id: string; name: string; dosage: string; times: string[];
  instructions: string | null; drug_key: string | null;
  form: string | null; pill_color: string | null;
};
type Log = { medicine_id: string; scheduled_for: string; status: string };
type Dose = {
  medicine: Medicine; time: string; scheduled_for: string;
  status?: "taken" | "skipped";
};
type DoseGroup = { time: string; doses: Dose[] };

function Today() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const today = format(new Date(), "yyyy-MM-dd");
  const now = new Date();

  const [confirm, setConfirm] = useState<null | { status: "taken" | "skipped"; name: string }>(null);

  useEffect(() => {
    if (!confirm) return;
    const t = setTimeout(() => setConfirm(null), 1300);
    return () => clearTimeout(t);
  }, [confirm]);

  const { data: meds } = useQuery({
    queryKey: ["medicines"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("medicines").select("*").eq("is_active", true).order("created_at");
      if (error) throw error;
      return data as unknown as Medicine[];
    },
  });

  const { data: logs } = useQuery({
    queryKey: ["logs", today],
    queryFn: async () => {
      const start = new Date(today + "T00:00:00").toISOString();
      const end = new Date(today + "T23:59:59").toISOString();
      const { data, error } = await supabase
        .from("adherence_logs").select("medicine_id,scheduled_for,status")
        .gte("scheduled_for", start).lte("scheduled_for", end);
      if (error) throw error;
      return data as Log[];
    },
  });

  const { data: weekLogs } = useQuery({
    queryKey: ["week-logs"],
    queryFn: async () => {
      const from = subDays(startOfDay(new Date()), 6).toISOString();
      const { data, error } = await supabase
        .from("adherence_logs").select("scheduled_for,status")
        .gte("scheduled_for", from);
      if (error) throw error;
      return data as { scheduled_for: string; status: string }[];
    },
  });

  const logDose = useMutation({
    mutationFn: async (v: { medicine_id: string; scheduled_for: string; status: "taken" | "skipped"; name: string }) => {
      if (!user) throw new Error("Not signed in");
      const { error } = await supabase.from("adherence_logs").upsert(
        {
          medicine_id: v.medicine_id, scheduled_for: v.scheduled_for, status: v.status,
          user_id: user.id, taken_at: v.status === "taken" ? new Date().toISOString() : null,
        },
        { onConflict: "user_id,medicine_id,scheduled_for" }
      );
      if (error) throw error;
      return v;
    },
    onSuccess: (v) => {
      setConfirm({ status: v.status, name: v.name });
      qc.invalidateQueries({ queryKey: ["logs", today] });
      qc.invalidateQueries({ queryKey: ["week-logs"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  // Build flat doses then group by time
  const doses: Dose[] = (meds ?? []).flatMap((m) =>
    m.times.map((t) => {
      const scheduled_for = new Date(`${today}T${t}:00`).toISOString();
      const log = logs?.find((l) => l.medicine_id === m.id && l.scheduled_for === scheduled_for);
      return { medicine: m, time: t, scheduled_for, status: log?.status as "taken" | "skipped" | undefined };
    })
  ).sort((a, b) => a.time.localeCompare(b.time));

  const groups: DoseGroup[] = useMemo(() => {
    const map = new Map<string, Dose[]>();
    for (const d of doses) {
      if (!map.has(d.time)) map.set(d.time, []);
      map.get(d.time)!.push(d);
    }
    return Array.from(map.entries()).map(([time, doses]) => ({ time, doses }));
  }, [doses]);

  const total = doses.length;
  const takenCount = doses.filter((d) => d.status === "taken").length;
  const progress = total ? Math.round((takenCount / total) * 100) : 0;

  // Next group = first group with any unlogged dose
  const nextGroup =
    groups.find((g) => g.doses.some((d) => !d.status) && g.time >= format(now, "HH:mm")) ??
    groups.find((g) => g.doses.some((d) => !d.status));

  function logGroup(g: DoseGroup, status: "taken" | "skipped") {
    const pending = g.doses.filter((d) => !d.status);
    if (!pending.length) return;
    pending.forEach((d) => logDose.mutate({
      medicine_id: d.medicine.id, scheduled_for: d.scheduled_for, status, name: d.medicine.name,
    }));
  }

  const weekStats = useMemo(() => {
    const map = new Map<string, { taken: number; total: number }>();
    for (let i = 6; i >= 0; i--) {
      const k = format(subDays(now, i), "yyyy-MM-dd");
      map.set(k, { taken: 0, total: 0 });
    }
    weekLogs?.forEach((l) => {
      const k = format(new Date(l.scheduled_for), "yyyy-MM-dd");
      const cur = map.get(k);
      if (!cur) return;
      cur.total++;
      if (l.status === "taken") cur.taken++;
    });
    const days = Array.from(map.entries());
    let streak = 0;
    for (let i = days.length - 1; i >= 0; i--) {
      const d = days[i][1];
      if (d.total > 0 && d.taken === d.total) streak++;
      else if (d.total > 0) break;
    }
    const totalTaken = days.reduce((s, [, v]) => s + v.taken, 0);
    const totalAll = days.reduce((s, [, v]) => s + v.total, 0);
    const rate = totalAll ? Math.round((totalTaken / totalAll) * 100) : 0;
    return { days, streak, rate, totalTaken };
  }, [weekLogs]);

  const greet = now.getHours() < 12 ? "Good morning" : now.getHours() < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="px-5 pt-7 pb-2">
      <header className="mb-5">
        <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">{format(now, "EEEE, MMMM d")}</p>
        <h1 className="text-3xl font-bold mt-1 font-display">{greet} 👋</h1>
      </header>

      {/* Bento dashboard */}
      <div className="grid grid-cols-4 gap-2.5 mb-5">
        <div
          className="col-span-4 rounded-3xl p-5 text-white relative overflow-hidden"
          style={{ background: "var(--gradient-sunrise)", boxShadow: "var(--shadow-lift)" }}
        >
          <div className="absolute -right-8 -top-8 size-40 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -right-12 -bottom-12 size-32 rounded-full bg-white/10 blur-2xl" />
          <div className="relative">
            <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider opacity-90 font-semibold">
              <Sparkles className="size-3.5" />
              {nextGroup ? `Next dose · ${nextGroup.doses.length} med${nextGroup.doses.length > 1 ? "s" : ""}` : total === 0 ? "Welcome" : "All done!"}
            </div>
            {nextGroup ? (
              <>
                <NextTime time={nextGroup.time} />
                <div className="mt-3 space-y-1.5 max-h-[7.5rem] overflow-y-auto pr-1 -mr-1">
                  {nextGroup.doses.length > 2 && (
                    <p className="text-[10px] uppercase tracking-wider opacity-80 font-semibold pb-0.5">
                      {nextGroup.doses.length} meds · scroll for more
                    </p>
                  )}
                  {nextGroup.doses.map((d) => {
                    const Ic = iconForForm(d.medicine.form);
                    const color = d.medicine.pill_color ?? DEFAULT_PILL_COLOR;
                    return (
                      <Link
                        key={d.medicine.id}
                        to="/medicine/$id" params={{ id: d.medicine.id }}
                        className="flex items-center gap-2.5 rounded-xl bg-white/15 backdrop-blur px-3 py-2 active:scale-[0.99]"
                      >
                        <div
                          className="size-8 rounded-lg flex items-center justify-center shrink-0"
                          style={{ background: color }}
                        >
                          <Ic className="size-4 text-white" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold text-sm truncate">{d.medicine.name}</p>
                          <p className="text-[11px] opacity-90 truncate">{d.medicine.dosage}</p>
                        </div>
                        {d.status === "taken" && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/30">✓</span>
                        )}
                        {d.status === "skipped" && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/20">SKIP</span>
                        )}
                      </Link>
                    );
                  })}
                </div>
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => logGroup(nextGroup, "taken")}
                    className="flex-1 h-11 rounded-xl bg-white text-neutral-900 text-sm font-bold flex items-center justify-center gap-1.5 active:scale-95 transition-transform"
                  >
                    <Check className="size-4" /> Took {nextGroup.doses.filter((d) => !d.status).length > 1 ? "all" : "it"}
                  </button>
                  <button
                    onClick={() => logGroup(nextGroup, "skipped")}
                    className="px-4 h-11 rounded-xl bg-white/20 text-white text-sm font-semibold backdrop-blur active:scale-95 transition-transform"
                  >
                    Skip
                  </button>
                </div>
              </>
            ) : total === 0 ? (
              <>
                <p className="mt-3 text-lg font-semibold">Let's get you set up</p>
                <p className="text-sm opacity-90">Scan a prescription or add a medicine.</p>
              </>
            ) : (
              <>
                <p className="mt-3 text-2xl font-bold font-display">100% complete 🎉</p>
                <p className="text-sm opacity-90">Great job staying on top of your meds today.</p>
              </>
            )}
          </div>
        </div>

        <Tile className="col-span-2 row-span-2 flex flex-col items-center justify-center">
          <ProgressRing value={progress} />
          <p className="mt-3 text-xs text-muted-foreground uppercase tracking-wider font-semibold">Today</p>
          <p className="text-sm font-semibold">{takenCount} of {total} doses</p>
        </Tile>

        <Tile className="col-span-2 bg-gradient-to-br from-coral/20 to-coral/5">
          <div className="size-9 rounded-xl bg-coral/20 flex items-center justify-center">
            <Flame className="size-5 text-coral" />
          </div>
          <p className="text-2xl font-bold mt-2 font-display tabular-nums">{weekStats.streak}<span className="text-sm font-normal text-muted-foreground"> day</span></p>
          <p className="text-xs text-muted-foreground">Perfect streak</p>
        </Tile>

        <Tile className="col-span-2">
          <div className="size-9 rounded-xl bg-primary/15 flex items-center justify-center">
            <TrendingUp className="size-5 text-primary" />
          </div>
          <p className="text-2xl font-bold mt-2 font-display tabular-nums">{weekStats.rate}%</p>
          <p className="text-xs text-muted-foreground">7-day adherence</p>
        </Tile>

        <Tile className="col-span-4">
          <div className="flex items-center justify-between mb-2.5">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">This week</p>
              <p className="text-sm font-semibold">{weekStats.totalTaken} doses taken</p>
            </div>
            <Link to="/history" className="text-xs text-primary font-semibold flex items-center gap-0.5">
              Details <ChevronRight className="size-3" />
            </Link>
          </div>
          <div className="flex items-end justify-between gap-1.5 h-24">
            {weekStats.days.map(([k, v]) => {
              const pct = v.total ? (v.taken / v.total) * 100 : 0;
              const isToday = k === today;
              const day = format(new Date(k), "EEEEE");
              return (
                <div key={k} className="flex-1 flex flex-col items-center gap-1.5">
                  <div className="w-full h-20 rounded-md bg-muted/60 relative overflow-hidden">
                    <div
                      className="absolute bottom-0 inset-x-0 rounded-md transition-all"
                      style={{
                        height: `${Math.max(pct, v.total ? 6 : 0)}%`,
                        background: isToday ? "var(--gradient-sunrise)" : "var(--gradient-primary)",
                        opacity: v.total ? 1 : 0.3,
                      }}
                    />
                  </div>
                  <span className={`text-[10px] font-semibold ${isToday ? "text-primary" : "text-muted-foreground"}`}>{day}</span>
                </div>
              );
            })}
          </div>
        </Tile>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-3 gap-2 mb-5">
        <QuickAction icon={ScanLine} label="Scan" onClick={() => navigate({ to: "/scan" })} primary />
        <QuickAction icon={Plus} label="Add med" onClick={() => navigate({ to: "/add" })} />
        <QuickAction icon={Watch} label="Devices" onClick={() => navigate({ to: "/devices" })} />
      </div>

      {/* Schedule — grouped by time */}
      <div className="flex items-baseline justify-between mb-2.5">
        <h2 className="text-lg font-bold font-display">Schedule</h2>
        <span className="text-xs text-muted-foreground">{groups.length} time slot{groups.length === 1 ? "" : "s"} · {total} doses</span>
      </div>

      {groups.length === 0 ? (
        <div className="text-center py-12 px-6 rounded-3xl border border-dashed border-border">
          <div className="size-14 rounded-2xl bg-accent mx-auto flex items-center justify-center mb-4 animate-float">
            <Sparkles className="size-6 text-primary" />
          </div>
          <h3 className="font-semibold">No reminders yet</h3>
          <p className="text-sm text-muted-foreground mt-1">Scan a prescription or add a medicine manually.</p>
        </div>
      ) : (
        <ul className="space-y-3">
          {groups.map((g) => {
            const isPast = g.time < format(now, "HH:mm");
            const parts = to12hParts(g.time);
            const allDone = g.doses.every((d) => d.status);
            return (
              <li key={g.time} className="rounded-2xl bg-card border border-border overflow-hidden" style={{ boxShadow: "var(--shadow-soft)" }}>
                {/* Time header */}
                <div className={`px-4 py-2.5 flex items-center justify-between ${
                  allDone ? "bg-success/10" : isPast ? "bg-coral/10" : "bg-primary/8"
                }`}>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-xl font-bold font-display tabular-nums">{parts.h}:{parts.m}</span>
                    <span className="text-xs font-bold opacity-70">{parts.p}</span>
                  </div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                    {g.doses.length} med{g.doses.length > 1 ? "s" : ""}
                  </span>
                </div>
                {/* Doses */}
                <ul className="divide-y divide-border">
                  {g.doses.map((d) => {
                    const Ic = iconForForm(d.medicine.form);
                    const color = d.medicine.pill_color ?? DEFAULT_PILL_COLOR;
                    return (
                      <li key={d.medicine.id + d.time} className="p-3 flex items-center gap-3">
                        <div
                          className="size-11 rounded-xl flex items-center justify-center shrink-0"
                          style={{ background: color }}
                        >
                          <Ic className="size-5 text-white" />
                        </div>
                        <Link to="/medicine/$id" params={{ id: d.medicine.id }} className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <p className="font-semibold truncate">{d.medicine.name}</p>
                            <span className="text-xs text-muted-foreground">{d.medicine.dosage}</span>
                          </div>
                          {d.medicine.instructions && (
                            <p className="text-xs text-muted-foreground truncate flex items-center gap-1 mt-0.5">
                              <Clock className="size-3" /> {d.medicine.instructions}
                            </p>
                          )}
                        </Link>
                        {d.status === "taken" ? (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-success/15 text-success font-semibold">✓ Taken</span>
                        ) : d.status === "skipped" ? (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-muted text-muted-foreground font-semibold">Skipped</span>
                        ) : (
                          <div className="flex gap-1.5">
                            <button
                              onClick={() => logDose.mutate({ medicine_id: d.medicine.id, scheduled_for: d.scheduled_for, status: "taken", name: d.medicine.name })}
                              className="size-10 rounded-xl bg-success text-success-foreground flex items-center justify-center active:scale-90 transition-transform"
                              aria-label="Took"
                            >
                              <Check className="size-4" strokeWidth={3} />
                            </button>
                            <button
                              onClick={() => logDose.mutate({ medicine_id: d.medicine.id, scheduled_for: d.scheduled_for, status: "skipped", name: d.medicine.name })}
                              className="size-10 rounded-xl bg-muted text-muted-foreground flex items-center justify-center active:scale-90 transition-transform"
                              aria-label="Skip"
                            >
                              <X className="size-4" strokeWidth={3} />
                            </button>
                          </div>
                        )}
                      </li>
                    );
                  })}
                </ul>
                {/* Group actions when multiple */}
                {g.doses.length > 1 && g.doses.some((d) => !d.status) && (
                  <div className="px-3 pb-3 pt-1 flex gap-2">
                    <button
                      onClick={() => logGroup(g, "taken")}
                      className="flex-1 h-9 rounded-lg bg-success/15 text-success text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95"
                    >
                      <Check className="size-3.5" /> Took all
                    </button>
                    <button
                      onClick={() => logGroup(g, "skipped")}
                      className="flex-1 h-9 rounded-lg bg-muted text-muted-foreground text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95"
                    >
                      <X className="size-3.5" /> Skip all
                    </button>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}

      <div className="mt-6">
        <DisclaimerCard compact />
      </div>

      {/* Confirmation popup overlay */}
      {confirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
          <div className="absolute inset-0 bg-black/30 animate-in fade-in" />
          <div className="relative bg-card rounded-3xl px-7 py-6 flex flex-col items-center animate-success-pop shadow-2xl border border-border">
            <div
              className={`size-20 rounded-full flex items-center justify-center ${
                confirm.status === "taken" ? "bg-success text-success-foreground" : "bg-muted text-muted-foreground"
              }`}
            >
              {confirm.status === "taken"
                ? <Check className="size-10" strokeWidth={3.5} />
                : <X className="size-10" strokeWidth={3.5} />}
            </div>
            <p className="mt-4 font-bold text-lg font-display">
              {confirm.status === "taken" ? "Logged ✓" : "Skipped"}
            </p>
            <p className="text-sm text-muted-foreground mt-1 text-center max-w-[200px] truncate">{confirm.name}</p>
          </div>
        </div>
      )}
    </div>
  );
}

function NextTime({ time }: { time: string }) {
  const p = to12hParts(time);
  return (
    <div className="mt-2 flex items-baseline gap-2">
      <span className="text-5xl font-bold tabular-nums font-display">{p.h}:{p.m}</span>
      <span className="text-lg font-semibold opacity-90">{p.p}</span>
      <span className="text-sm opacity-90">· in {timeUntil(time)}</span>
    </div>
  );
}

function Tile({ className = "", children }: { className?: string; children: React.ReactNode }) {
  return (
    <div
      className={`rounded-2xl bg-card border border-border p-3.5 ${className}`}
      style={{ boxShadow: "var(--shadow-soft)" }}
    >
      {children}
    </div>
  );
}

function QuickAction({ icon: Icon, label, onClick, primary }: { icon: any; label: string; onClick: () => void; primary?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`h-14 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2 transition-transform active:scale-95 ${
        primary ? "text-white" : "bg-card border border-border text-foreground"
      }`}
      style={primary ? { background: "var(--gradient-primary)", boxShadow: "var(--shadow-soft)" } : { boxShadow: "var(--shadow-soft)" }}
    >
      <Icon className="size-4" /> {label}
    </button>
  );
}

function ProgressRing({ value }: { value: number }) {
  const size = 110;
  const stroke = 11;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--muted)" strokeWidth={stroke} fill="none" />
      <circle
        cx={size / 2} cy={size / 2} r={r} stroke="url(#prog-grad)" strokeWidth={stroke}
        fill="none" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={offset}
        style={{ transition: "stroke-dashoffset 0.6s cubic-bezier(0.22, 1, 0.36, 1)" }}
      />
      <defs>
        <linearGradient id="prog-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="oklch(0.72 0.16 170)" />
          <stop offset="100%" stopColor="oklch(0.62 0.18 195)" />
        </linearGradient>
      </defs>
      <text x="50%" y="50%" textAnchor="middle" dy="0.35em" className="rotate-90 origin-center fill-foreground font-bold text-2xl font-display">{value}%</text>
    </svg>
  );
}

function timeUntil(hhmm: string): string {
  const [h, m] = hhmm.split(":").map(Number);
  const now = new Date();
  const target = new Date(); target.setHours(h, m, 0, 0);
  let diff = (target.getTime() - now.getTime()) / 60000;
  if (diff < 0) diff += 24 * 60;
  if (diff < 1) return "now";
  if (diff < 60) return `${Math.round(diff)} min`;
  const hrs = Math.floor(diff / 60); const mins = Math.round(diff % 60);
  return mins ? `${hrs}h ${mins}m` : `${hrs}h`;
}
// keep to12h import alive
void to12h;
