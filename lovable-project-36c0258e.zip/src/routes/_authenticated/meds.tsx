import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Plus, ChevronRight, Clock, ScanLine, Search, Pill, LayoutGrid, ListOrdered } from "lucide-react";
import { useState, useMemo } from "react";
import { to12h, to12hParts } from "@/lib/time";
import { iconForForm, DEFAULT_PILL_COLOR } from "@/lib/medForm";

export const Route = createFileRoute("/_authenticated/meds")({ component: Meds });

type Med = {
  id: string; name: string; dosage: string; times: string[];
  instructions: string | null; is_active: boolean; form: string | null;
  reason: string | null; pill_color: string | null;
};

type View = "list" | "byTime";

function Meds() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [view, setView] = useState<View>("list");

  const { data: meds, isLoading } = useQuery({
    queryKey: ["medicines-all"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("medicines").select("*").order("is_active", { ascending: false }).order("name");
      if (error) throw error;
      return data as unknown as Med[];
    },
  });

  const filtered = useMemo(() => {
    if (!meds) return [];
    const s = q.trim().toLowerCase();
    if (!s) return meds;
    return meds.filter((m) =>
      m.name.toLowerCase().includes(s) ||
      (m.reason ?? "").toLowerCase().includes(s),
    );
  }, [meds, q]);

  const active = filtered.filter((m) => m.is_active);
  const archived = filtered.filter((m) => !m.is_active);

  // Group active by time (e.g. 09:00 -> [med1, med2])
  const groupedByTime = useMemo(() => {
    const map = new Map<string, Med[]>();
    for (const m of active) {
      for (const t of m.times) {
        if (!map.has(t)) map.set(t, []);
        const arr = map.get(t)!;
        if (!arr.find((x) => x.id === m.id)) arr.push(m);
      }
    }
    return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [active]);

  return (
    <div className="px-5 pt-7 pb-4">
      <header className="flex items-baseline justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight font-display">My Meds</h1>
          <p className="text-sm text-muted-foreground mt-1">All your medicines & reminders.</p>
        </div>
      </header>

      {/* Search */}
      <div className="mt-5 relative">
        <Search className="size-4 text-muted-foreground absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search medicines"
          className="w-full h-11 pl-10 pr-3 rounded-2xl bg-card border border-border text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          style={{ boxShadow: "var(--shadow-soft)" }}
        />
      </div>

      <div className="grid grid-cols-2 gap-2 mt-3">
        <button
          onClick={() => navigate({ to: "/add" })}
          className="h-14 rounded-2xl text-white font-semibold flex items-center justify-center gap-2 active:scale-95 transition-transform"
          style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-soft)" }}
        >
          <Plus className="size-4" /> Add Med
        </button>
        <button
          onClick={() => navigate({ to: "/scan" })}
          className="h-14 rounded-2xl bg-card border border-border font-semibold text-foreground flex items-center justify-center gap-2 active:scale-95 transition-transform"
          style={{ boxShadow: "var(--shadow-soft)" }}
        >
          <ScanLine className="size-4 text-primary" /> Scan
        </button>
      </div>

      {/* View toggle */}
      <div className="mt-5 flex items-center justify-between">
        <h2 className="text-lg font-bold font-display">
          {view === "list" ? "Active reminders" : "Grouped by time"}
        </h2>
        <div className="grid grid-cols-2 p-1 rounded-xl bg-muted border border-border text-xs">
          <button
            onClick={() => setView("list")}
            className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1 transition-all ${
              view === "list" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"
            }`}
          >
            <LayoutGrid className="size-3" /> All
          </button>
          <button
            onClick={() => setView("byTime")}
            className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1 transition-all ${
              view === "byTime" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"
            }`}
          >
            <ListOrdered className="size-3" /> By time
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="mt-3 space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-20 rounded-2xl bg-muted/40 animate-pulse" />
          ))}
        </div>
      ) : active.length === 0 ? (
        <div className="mt-3 text-center py-10 px-6 rounded-3xl border border-dashed border-border">
          <div className="size-14 rounded-2xl bg-accent mx-auto flex items-center justify-center mb-3 animate-float">
            <Pill className="size-6 text-primary" />
          </div>
          <p className="font-semibold">No reminders yet</p>
          <p className="text-sm text-muted-foreground mt-1">Tap Add Med or Scan to get started.</p>
        </div>
      ) : view === "list" ? (
        <ul className="mt-3 space-y-2">
          {active.map((m) => <MedCard key={m.id} m={m} />)}
        </ul>
      ) : (
        <ul className="mt-3 space-y-3">
          {groupedByTime.map(([time, items]) => {
            const p = to12hParts(time);
            return (
              <li key={time} className="rounded-2xl bg-card border border-border overflow-hidden"
                style={{ boxShadow: "var(--shadow-soft)" }}>
                <div className="px-4 py-2.5 flex items-center justify-between bg-primary/8">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-xl font-bold font-display tabular-nums">{p.h}:{p.m}</span>
                    <span className="text-xs font-bold opacity-70">{p.p}</span>
                  </div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                    {items.length} med{items.length > 1 ? "s" : ""}
                  </span>
                </div>
                <ul className="divide-y divide-border">
                  {items.map((m) => {
                    const Ic = iconForForm(m.form);
                    const color = m.pill_color ?? DEFAULT_PILL_COLOR;
                    return (
                      <li key={m.id}>
                        <Link to="/medicine/$id" params={{ id: m.id }}
                          className="flex items-center gap-3 p-3 active:bg-muted/30">
                          <div className="size-10 rounded-xl flex items-center justify-center shrink-0"
                            style={{ background: color }}>
                            <Ic className="size-5 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-sm truncate">{m.name}</p>
                            <p className="text-xs text-muted-foreground truncate">{m.dosage}{m.reason ? ` · ${m.reason}` : ""}</p>
                          </div>
                          <ChevronRight className="size-4 text-muted-foreground shrink-0" />
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </li>
            );
          })}
        </ul>
      )}

      {archived.length > 0 && (
        <>
          <h2 className="mt-6 text-sm font-bold uppercase tracking-wider text-muted-foreground">Archived</h2>
          <ul className="mt-2 space-y-2 opacity-70">
            {archived.map((m) => <MedCard key={m.id} m={m} />)}
          </ul>
        </>
      )}
    </div>
  );
}

function MedCard({ m }: { m: Med }) {
  const Ic = iconForForm(m.form);
  const color = m.pill_color ?? DEFAULT_PILL_COLOR;
  return (
    <li>
      <Link
        to="/medicine/$id" params={{ id: m.id }}
        className="block rounded-2xl bg-card border border-border p-3.5 active:scale-[0.99] transition-transform"
        style={{ boxShadow: "var(--shadow-soft)" }}
      >
        <div className="flex items-center gap-3">
          <div className="size-12 rounded-2xl flex items-center justify-center shrink-0"
            style={{ background: color }}>
            <Ic className="size-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <p className="font-semibold truncate">{m.name}</p>
              <span className="text-xs text-muted-foreground">{m.dosage}</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5 flex-wrap">
              <Clock className="size-3 shrink-0" />
              <span>{m.times.map(to12h).join(" · ") || "No times set"}</span>
            </div>
            {m.reason && (
              <p className="text-[11px] text-muted-foreground mt-0.5 italic truncate">For {m.reason}</p>
            )}
          </div>
          <ChevronRight className="size-4 text-muted-foreground shrink-0" />
        </div>
      </Link>
    </li>
  );
}
