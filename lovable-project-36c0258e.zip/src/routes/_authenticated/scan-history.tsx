import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getScanHistory, removeScanHistory, clearScanHistory, type ScanHistoryItem } from "@/lib/scanHistory";
import { ArrowLeft, Trash2, ScanLine, FileText, PillBottle, Type, Image as ImageIcon } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export const Route = createFileRoute("/_authenticated/scan-history")({ component: ScanHistory });

function modeIcon(m: ScanHistoryItem["mode"]) {
  if (m === "rx") return FileText;
  if (m === "identify") return PillBottle;
  return Type;
}

function ScanHistory() {
  const navigate = useNavigate();
  const [items, setItems] = useState<ScanHistoryItem[]>([]);

  useEffect(() => { setItems(getScanHistory()); }, []);

  return (
    <div className="px-5 pt-6 pb-4">
      <button onClick={() => navigate({ to: "/scan" })} className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4">
        <ArrowLeft className="size-4" /> Back
      </button>

      <div className="flex items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight font-display">Scan history</h1>
          <p className="text-sm text-muted-foreground mt-1">Every scan you've made, kept on this device.</p>
        </div>
        {items.length > 0 && (
          <button onClick={() => { if (confirm("Clear all scan history?")) { clearScanHistory(); setItems([]); } }}
            className="h-9 px-3 rounded-xl border border-border text-xs font-semibold text-coral active:scale-95">
            Clear all
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="mt-8 rounded-3xl border border-dashed border-border p-8 text-center">
          <div className="size-12 rounded-2xl bg-accent mx-auto flex items-center justify-center mb-3 animate-float">
            <ScanLine className="size-6 text-primary" />
          </div>
          <p className="font-semibold">No scans yet</p>
          <p className="text-sm text-muted-foreground mt-1">Anything you scan or look up will appear here.</p>
        </div>
      ) : (
        <ul className="mt-5 space-y-2">
          {items.map((it) => {
            const Icon = modeIcon(it.mode);
            return (
              <li key={it.id} className="rounded-2xl bg-card border border-border p-3 flex items-center gap-3" style={{ boxShadow: "var(--shadow-soft)" }}>
                {it.thumb ? (
                  <img src={it.thumb} alt="" className="size-14 rounded-xl object-cover shrink-0" />
                ) : (
                  <div className="size-14 rounded-xl bg-accent flex items-center justify-center shrink-0">
                    <ImageIcon className="size-5 text-primary" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <Icon className="size-3.5 text-muted-foreground" />
                    <p className="font-bold text-sm truncate">{it.name}</p>
                  </div>
                  {it.summary && <p className="text-xs text-muted-foreground truncate">{it.summary}</p>}
                  <p className="text-[11px] text-muted-foreground">{formatDistanceToNow(new Date(it.at), { addSuffix: true })}</p>
                </div>
                <button onClick={() => { removeScanHistory(it.id); setItems(getScanHistory()); }}
                  className="size-9 rounded-lg text-muted-foreground hover:text-coral flex items-center justify-center">
                  <Trash2 className="size-4" />
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
