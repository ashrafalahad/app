import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useDoctors, type Doctor } from "@/lib/doctors";
import { ArrowLeft, Phone, Plus, Pencil, Trash2, Stethoscope, X, Loader2, Save } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/doctors")({ component: Doctors });

function Doctors() {
  const navigate = useNavigate();
  const { data: doctors, isLoading, upsert, remove } = useDoctors();
  const [editing, setEditing] = useState<null | Partial<Doctor>>(null);

  function openNew() { setEditing({ name: "", specialty: "", phone: "", notes: "" }); }
  function openEdit(d: Doctor) { setEditing(d); }

  async function save() {
    if (!editing?.name?.trim()) return toast.error("Name is required");
    await upsert.mutateAsync(editing);
    toast.success("Saved ✓");
    setEditing(null);
  }

  return (
    <div className="px-5 pt-6 pb-4">
      <button onClick={() => navigate({ to: "/profile" })} className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4">
        <ArrowLeft className="size-4" /> Back
      </button>

      <header className="flex items-baseline justify-between">
        <div>
          <h1 className="text-3xl font-bold font-display">My Doctors</h1>
          <p className="text-sm text-muted-foreground mt-1">Save multiple doctors — call any of them with one tap.</p>
        </div>
        <button onClick={openNew} className="size-10 rounded-xl text-white flex items-center justify-center active:scale-95"
          style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-soft)" }}>
          <Plus className="size-5" />
        </button>
      </header>

      {isLoading ? (
        <div className="mt-6 h-20 rounded-2xl bg-muted/40 animate-pulse" />
      ) : !doctors?.length ? (
        <div className="mt-6 text-center py-10 px-6 rounded-3xl border border-dashed border-border">
          <div className="size-14 rounded-2xl bg-accent mx-auto flex items-center justify-center mb-3 animate-float">
            <Stethoscope className="size-6 text-primary" />
          </div>
          <p className="font-semibold">No doctors saved</p>
          <p className="text-sm text-muted-foreground mt-1">Tap + to add your first doctor.</p>
          <button onClick={openNew} className="mt-4 h-10 px-4 rounded-xl bg-primary text-primary-foreground text-sm font-semibold inline-flex items-center gap-1.5">
            <Plus className="size-4" /> Add doctor
          </button>
        </div>
      ) : (
        <ul className="mt-5 space-y-2">
          {doctors.map((d) => {
            const tel = d.phone?.replace(/[^+\d]/g, "");
            return (
              <li key={d.id} className="rounded-2xl bg-card border border-border p-3.5 flex items-center gap-3"
                style={{ boxShadow: "var(--shadow-soft)" }}>
                <div className="size-12 rounded-2xl flex items-center justify-center shrink-0"
                  style={{ background: "var(--gradient-sunrise)" }}>
                  <Stethoscope className="size-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">Dr. {d.name}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {d.specialty ? `${d.specialty} · ` : ""}{d.phone || "No number"}
                  </p>
                </div>
                {tel && (
                  <a href={`tel:${tel}`} className="size-10 rounded-xl bg-success text-success-foreground flex items-center justify-center active:scale-90">
                    <Phone className="size-4" />
                  </a>
                )}
                <button onClick={() => openEdit(d)} className="size-10 rounded-xl border border-border flex items-center justify-center active:scale-90">
                  <Pencil className="size-4" />
                </button>
                <button onClick={() => { if (confirm(`Remove Dr. ${d.name}?`)) remove.mutate(d.id); }}
                  className="size-10 rounded-xl text-coral border border-border flex items-center justify-center active:scale-90">
                  <Trash2 className="size-4" />
                </button>
              </li>
            );
          })}
        </ul>
      )}

      {editing && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setEditing(null)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div className="relative w-full bg-card rounded-t-3xl p-5 pb-8 max-w-md mx-auto space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="size-10 h-1 rounded-full bg-muted mx-auto mb-2" />
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold font-display">{editing.id ? "Edit doctor" : "New doctor"}</h3>
              <button onClick={() => setEditing(null)} className="size-8 rounded-lg text-muted-foreground">
                <X className="size-4" />
              </button>
            </div>
            <input value={editing.name ?? ""} onChange={(e) => setEditing((v) => ({ ...v!, name: e.target.value }))}
              placeholder="Name (e.g. Jane Smith)"
              className="w-full h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            <input value={editing.specialty ?? ""} onChange={(e) => setEditing((v) => ({ ...v!, specialty: e.target.value }))}
              placeholder="Specialty (e.g. Cardiologist)"
              className="w-full h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            <input type="tel" value={editing.phone ?? ""} onChange={(e) => setEditing((v) => ({ ...v!, phone: e.target.value }))}
              placeholder="Phone (e.g. +1 555 123 4567)"
              className="w-full h-11 px-3 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            <textarea value={editing.notes ?? ""} onChange={(e) => setEditing((v) => ({ ...v!, notes: e.target.value }))}
              rows={2} placeholder="Notes (clinic address, hours, etc.)"
              className="w-full px-3 py-2 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            <button onClick={save} disabled={upsert.isPending}
              className="w-full h-12 rounded-xl text-white font-semibold flex items-center justify-center gap-2 active:scale-95"
              style={{ background: "var(--gradient-primary)" }}>
              {upsert.isPending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              Save doctor
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
