import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { getDrugInfo, getCachedDrugInfo } from "@/lib/medicines.functions";
import {
  ArrowLeft, Trash2, Loader2, Phone, AlertOctagon, Activity,
  Clock, Utensils, Baby, Pencil, Plus, Check, X, Sparkles, Pill,
} from "lucide-react";
import { toast } from "sonner";
import { DisclaimerCard } from "@/components/DisclaimerCard";
import { useState, useEffect } from "react";
import { to12h } from "@/lib/time";
import { useDoctors } from "@/lib/doctors";
import { iconForForm, DEFAULT_PILL_COLOR, PILL_COLORS } from "@/lib/medForm";

export const Route = createFileRoute("/_authenticated/medicine/$id")({ component: MedDetail });

function MedDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fetchInfo = useServerFn(getDrugInfo);
  const fetchCached = useServerFn(getCachedDrugInfo);
  const { data: doctors } = useDoctors();

  const { data: med, isLoading } = useQuery({
    queryKey: ["medicine", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("medicines").select("*").eq("id", id).single();
      if (error) throw error;
      return data as any;
    },
  });

  // Only load cached info automatically (no AI call). User taps button to research.
  const { data: info } = useQuery({
    queryKey: ["drug-info-cached", med?.name],
    queryFn: () => fetchCached({ data: { name: med!.name } }),
    enabled: !!med?.name,
    staleTime: Infinity,
    gcTime: Infinity,
  });

  const researchAI = useMutation({
    mutationFn: () => fetchInfo({ data: { name: med!.name } }),
    onSuccess: (data) => {
      qc.setQueryData(["drug-info-cached", med?.name], data);
      toast.success("Saved · won't need to research again unless you edit the name");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const [editing, setEditing] = useState(false);
  const [times, setTimes] = useState<string[]>([]);
  const [name, setName] = useState("");
  const [dosage, setDosage] = useState("");
  const [instructions, setInstructions] = useState("");
  const [pillColor, setPillColor] = useState<string>(DEFAULT_PILL_COLOR);

  useEffect(() => {
    if (med) {
      setTimes(med.times ?? []);
      setName(med.name);
      setDosage(med.dosage);
      setInstructions(med.instructions ?? "");
      setPillColor(med.pill_color ?? DEFAULT_PILL_COLOR);
    }
  }, [med]);

  const saveEdit = useMutation({
    mutationFn: async () => {
      const newName = name.trim();
      const { error } = await supabase.from("medicines").update({
        name: newName, dosage: dosage.trim(), instructions: instructions.trim() || null,
        times: times.filter(Boolean).sort(),
        drug_key: newName.toLowerCase(),
        pill_color: pillColor,
      } as any).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["medicine", id] });
      qc.invalidateQueries({ queryKey: ["medicines"] });
      qc.invalidateQueries({ queryKey: ["medicines-all"] });
      if (med && name.trim() !== med.name) qc.invalidateQueries({ queryKey: ["drug-info-cached"] });
      setEditing(false);
      toast.success("Updated ✓");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("medicines").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["medicines"] });
      qc.invalidateQueries({ queryKey: ["medicines-all"] });
      toast.success("Deleted");
      navigate({ to: "/meds" });
    },
  });

  if (isLoading) return <Loading />;
  if (!med) return <div className="p-5">Not found</div>;

  const FormIcon = iconForForm(med.form);

  return (
    <div className="px-5 pt-6 pb-8">
      <button onClick={() => navigate({ to: "/meds" })} className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4 active:scale-95 transition-transform">
        <ArrowLeft className="size-4" /> Back
      </button>

      {/* Hero — use pill color */}
      <div className="rounded-3xl p-5 text-white relative overflow-hidden"
        style={{ background: `linear-gradient(135deg, ${pillColor}, ${pillColor}cc)`, boxShadow: "var(--shadow-lift)" }}>
        <div className="absolute -right-8 -top-8 size-40 rounded-full bg-white/10 blur-2xl" />
        <div className="relative">
          <div className="flex items-center gap-2">
            <div className="size-9 rounded-xl bg-white/25 backdrop-blur flex items-center justify-center">
              <FormIcon className="size-5" />
            </div>
            <span className="text-xs uppercase tracking-wide opacity-90 font-semibold">{med.form ?? "Medicine"}</span>
            <button
              onClick={() => setEditing((e) => !e)}
              className="ml-auto size-9 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center active:scale-90"
              aria-label="Edit"
            >
              {editing ? <X className="size-4" /> : <Pencil className="size-4" />}
            </button>
          </div>
          {editing ? (
            <input
              value={name} onChange={(e) => setName(e.target.value)}
              className="mt-3 w-full text-2xl font-bold bg-white/15 rounded-lg px-2 py-1 focus:outline-none focus:bg-white/25"
            />
          ) : (
            <h1 className="text-2xl font-bold mt-3 font-display">{med.name}</h1>
          )}
          {editing ? (
            <input
              value={dosage} onChange={(e) => setDosage(e.target.value)}
              className="mt-1 w-full text-sm bg-white/15 rounded-lg px-2 py-1 focus:outline-none focus:bg-white/25"
            />
          ) : (
            <p className="opacity-90 mt-1">{med.dosage}</p>
          )}
          {med.reason && !editing && <p className="text-sm opacity-80 mt-1 italic">For: {med.reason}</p>}
        </div>
      </div>

      {/* Reminder times + edit */}
      <div className="mt-5 rounded-2xl bg-card border border-border p-4" style={{ boxShadow: "var(--shadow-soft)" }}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-sm font-bold">
            <Clock className="size-4 text-primary" /> Reminders
          </div>
          {editing && (
            <button
              onClick={() => setTimes((t) => [...t, "12:00"])}
              className="text-xs text-primary font-semibold flex items-center gap-1 active:scale-95"
            >
              <Plus className="size-3" /> Add time
            </button>
          )}
        </div>
        {editing ? (
          <div className="space-y-2">
            {times.map((t, i) => (
              <div key={i} className="flex items-center gap-2">
                <input
                  type="time" value={t}
                  onChange={(e) => setTimes((arr) => arr.map((x, j) => j === i ? e.target.value : x))}
                  className="flex-1 h-10 px-3 rounded-xl bg-background border border-input text-sm"
                />
                <span className="text-xs text-muted-foreground w-16 text-right tabular-nums">{to12h(t)}</span>
                {times.length > 1 && (
                  <button onClick={() => setTimes((arr) => arr.filter((_, j) => j !== i))}
                    className="size-10 rounded-xl border border-border text-coral flex items-center justify-center active:scale-95">
                    <Trash2 className="size-4" />
                  </button>
                )}
              </div>
            ))}
            <textarea
              value={instructions} onChange={(e) => setInstructions(e.target.value)}
              rows={2} placeholder="Instructions (e.g. with food)"
              className="w-full mt-2 px-3 py-2 rounded-xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />

            <div>
              <p className="text-xs font-semibold mb-2 mt-2">Pill color</p>
              <div className="flex gap-2 flex-wrap">
                {PILL_COLORS.map((c) => (
                  <button key={c} type="button" onClick={() => setPillColor(c)}
                    className={`size-8 rounded-full transition-all ${pillColor === c ? "ring-2 ring-offset-2 ring-foreground scale-110" : ""}`}
                    style={{ background: c }} aria-label={`Color ${c}`} />
                ))}
              </div>
            </div>

            <button
              onClick={() => saveEdit.mutate()} disabled={saveEdit.isPending}
              className="w-full h-11 rounded-xl text-white font-semibold flex items-center justify-center gap-2 active:scale-95 mt-2"
              style={{ background: "var(--gradient-primary)" }}
            >
              {saveEdit.isPending ? <Loader2 className="size-4 animate-spin" /> : <Check className="size-4" />}
              Save changes
            </button>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap gap-2">
              {med.times.map((t: string) => (
                <span key={t} className="text-sm font-semibold px-3 py-1.5 rounded-xl bg-primary/10 text-primary tabular-nums">
                  {to12h(t)}
                </span>
              ))}
            </div>
            {med.instructions && (
              <p className="text-sm text-muted-foreground mt-3">{med.instructions}</p>
            )}
          </>
        )}
      </div>

      {/* Doctors — multi */}
      {doctors && doctors.length > 0 ? (
        <div className="mt-3 space-y-2">
          {doctors.map((d) => {
            const tel = d.phone?.replace(/[^+\d]/g, "");
            return (
              <a
                key={d.id} href={tel ? `tel:${tel}` : undefined}
                className="block rounded-2xl flex items-center gap-3 px-4 py-3 active:scale-[0.98] transition-transform"
                style={{ background: "var(--gradient-sunrise)", boxShadow: "var(--shadow-soft)" }}
              >
                <div className="size-10 rounded-xl bg-white/25 flex items-center justify-center">
                  <Phone className="size-4 text-white" />
                </div>
                <div className="flex-1 text-left min-w-0">
                  <p className="text-sm font-bold text-white truncate">Call Dr. {d.name}</p>
                  <p className="text-[11px] text-white/90 truncate">
                    {d.specialty ? `${d.specialty} · ` : ""}{d.phone || "No number"}
                  </p>
                </div>
              </a>
            );
          })}
        </div>
      ) : (
        <button onClick={() => navigate({ to: "/doctors" })}
          className="mt-3 w-full h-12 rounded-2xl bg-card border border-border flex items-center justify-center gap-2 text-sm font-semibold text-muted-foreground active:scale-95">
          <Phone className="size-4" /> Add a doctor contact
        </button>
      )}

      {/* AI drug info — manual research, then cached forever */}
      <div className="mt-5">
        {!info ? (
          <div className="rounded-2xl bg-card border border-border p-5 text-center" style={{ boxShadow: "var(--shadow-soft)" }}>
            <div className="size-12 rounded-2xl mx-auto flex items-center justify-center" style={{ background: "var(--gradient-primary)" }}>
              <Sparkles className="size-6 text-white" />
            </div>
            <p className="mt-3 font-bold text-sm font-display">Want the full drug profile?</p>
            <p className="text-xs text-muted-foreground mt-1 max-w-xs mx-auto">
              We'll research <strong className="text-foreground">{med.name}</strong> once with AI and keep the details here forever — no re-scanning until you edit the name.
            </p>
            <button onClick={() => researchAI.mutate()} disabled={researchAI.isPending}
              className="mt-4 w-full h-11 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2 active:scale-95 disabled:opacity-60"
              style={{ background: "var(--gradient-primary)" }}>
              {researchAI.isPending ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
              {researchAI.isPending ? "Researching…" : "Research with AI"}
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <Section icon={Activity} title="What it's for" body={info.what_for} />
            <Section icon={Pill} title="How it works" body={info.how_it_works} />
            <SectionList icon={AlertOctagon} title="Common side effects" tone="warning" items={info.common_side_effects ?? undefined} />
            <SectionList icon={AlertOctagon} title="Serious side effects" tone="destructive" items={info.serious_side_effects ?? undefined} />
            <Section icon={Clock} title="If you miss a dose" body={info.missed_dose} />
            <SectionList icon={Utensils} title="Interactions" items={info.interactions ?? undefined} />
            <Section icon={Baby} title="Pregnancy" body={info.pregnancy_warning} />
          </div>
        )}
      </div>

      <button onClick={() => { if (confirm("Delete this reminder?")) del.mutate(); }} disabled={del.isPending}
        className="mt-5 w-full h-11 rounded-xl text-destructive text-sm font-semibold flex items-center justify-center gap-2 active:scale-95">
        <Trash2 className="size-4" /> Delete reminder
      </button>

      <div className="mt-6">
        <DisclaimerCard compact />
      </div>
    </div>
  );
}

function Loading() {
  return (
    <div className="px-5 pt-20 flex justify-center">
      <Loader2 className="size-5 animate-spin text-primary" />
    </div>
  );
}

function Section({ icon: Icon, title, body, loading }: { icon: any; title: string; body?: string | null; loading?: boolean }) {
  if (!loading && !body) return null;
  return (
    <div className="rounded-2xl bg-card border border-border p-4" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-center gap-2 text-sm font-semibold">
        <Icon className="size-4 text-primary" /> {title}
      </div>
      <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
        {loading ? <span className="opacity-50">Loading…</span> : body}
      </p>
    </div>
  );
}

function SectionList({ icon: Icon, title, items, loading, tone }: { icon: any; title: string; items?: string[]; loading?: boolean; tone?: "warning" | "destructive" }) {
  if (!loading && (!items || items.length === 0)) return null;
  const color = tone === "destructive" ? "text-destructive" : tone === "warning" ? "text-warning" : "text-primary";
  return (
    <div className="rounded-2xl bg-card border border-border p-4" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-center gap-2 text-sm font-semibold">
        <Icon className={`size-4 ${color}`} /> {title}
      </div>
      {loading ? (
        <p className="mt-2 text-sm text-muted-foreground opacity-50">Loading…</p>
      ) : (
        <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
          {items!.map((it, i) => (
            <li key={i} className="flex gap-2"><span className={color}>•</span>{it}</li>
          ))}
        </ul>
      )}
    </div>
  );
}
