import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import {
  LogOut, Shield, Stethoscope, Moon, Sun, Monitor, ChevronRight, RotateCcw,
  Bell, Watch, Download, HelpCircle, Phone, CalendarClock, StickyNote,
} from "lucide-react";
import { DisclaimerCard } from "@/components/DisclaimerCard";
import { useTheme } from "@/lib/theme";
import { useDisclaimerDismissed } from "@/lib/disclaimer";
import { useDoctors } from "@/lib/doctors";
import { toast } from "sonner";
import { useState } from "react";
import { format } from "date-fns";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";

export const Route = createFileRoute("/_authenticated/profile")({ component: Profile });

function Profile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { theme, setTheme } = useTheme();
  const { dismissed, reset } = useDisclaimerDismissed();
  const { data: doctors } = useDoctors();
  const [sheet, setSheet] = useState<null | "safety" | "privacy" | "help">(null);
  const [exporting, setExporting] = useState(false);

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/login" });
  }

  async function exportHistory() {
    setExporting(true);
    try {
      const { data, error } = await supabase
        .from("adherence_logs")
        .select("scheduled_for,status,taken_at,skip_reason,medicines(name,dosage)")
        .order("scheduled_for", { ascending: false });
      if (error) throw error;
      const rows = (data as any[]) ?? [];
      const today = format(new Date(), "yyyy-MM-dd HH:mm");
      const taken = rows.filter((r) => r.status === "taken").length;
      const skipped = rows.filter((r) => r.status === "skipped").length;
      const rate = rows.length ? Math.round((taken / rows.length) * 100) : 0;

      const header = ["Date", "Day", "Scheduled time", "Medicine", "Dosage", "Status", "Taken at", "Notes"];
      const body = rows.map((r) => {
        const d = new Date(r.scheduled_for);
        return [
          format(d, "yyyy-MM-dd"),
          format(d, "EEEE"),
          format(d, "h:mm a"),
          csvEsc(r.medicines?.name ?? ""),
          csvEsc(r.medicines?.dosage ?? ""),
          r.status,
          r.taken_at ? format(new Date(r.taken_at), "yyyy-MM-dd h:mm a") : "",
          csvEsc(r.skip_reason ?? ""),
        ].join(",");
      });

      const meta = [
        `# MediMind adherence export`,
        `# User,${csvEsc(user?.email ?? "")}`,
        `# Generated,${today}`,
        `# Total entries,${rows.length}`,
        `# Taken,${taken}`,
        `# Skipped,${skipped}`,
        `# Adherence rate,${rate}%`,
        ``,
      ];

      // BOM so Excel opens UTF-8 cleanly.
      const csv = "\uFEFF" + [...meta, header.join(","), ...body].join("\r\n");
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `medimind-adherence-${format(new Date(), "yyyy-MM-dd")}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success(`Exported ${rows.length} entries · ${rate}% adherence`);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setExporting(false);
    }
  }

  const initials = (user?.email ?? "?").slice(0, 2).toUpperCase();
  const docCount = doctors?.length ?? 0;

  return (
    <div className="px-5 pt-7 pb-2">
      <h1 className="text-3xl font-bold tracking-tight font-display">You</h1>

      <div className="mt-5 rounded-3xl p-5 text-white relative overflow-hidden" style={{ background: "var(--gradient-sunrise)", boxShadow: "var(--shadow-lift)" }}>
        <div className="absolute -right-8 -top-8 size-40 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex items-center gap-3">
          <div className="size-14 rounded-2xl bg-white/25 backdrop-blur flex items-center justify-center font-bold font-display text-lg">
            {initials}
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-semibold truncate">{user?.email}</p>
            <p className="text-xs opacity-90">MediMind member</p>
          </div>
        </div>
      </div>

      <Section title="Appearance">
        <div className="rounded-2xl bg-card border border-border p-1 grid grid-cols-3 gap-1" style={{ boxShadow: "var(--shadow-soft)" }}>
          <ThemeBtn active={theme === "light"} onClick={() => setTheme("light")} icon={Sun} label="Light" />
          <ThemeBtn active={theme === "dark"} onClick={() => setTheme("dark")} icon={Moon} label="Dark" />
          <ThemeBtn active={theme === "system"} onClick={() => setTheme("system")} icon={Monitor} label="Auto" />
        </div>
      </Section>

      <Section title="Personal">
        <Row
          icon={Phone}
          title="My doctor contacts"
          subtitle={docCount ? `${docCount} saved — tap to call` : "Save phone numbers, hidden everywhere else"}
          onClick={() => navigate({ to: "/doctors" })}
          accent
        />
        <Row
          icon={CalendarClock}
          title="Appointments"
          subtitle="Never miss a doctor visit — we'll remind you"
          onClick={() => navigate({ to: "/appointments" })}
        />
        <Row
          icon={StickyNote}
          title="Notes"
          subtitle="Personal medical notes & reminders"
          onClick={() => navigate({ to: "/notes" })}
        />
      </Section>

      <Section title="Settings">
        <Row icon={Watch} title="Devices & smartwatch" subtitle="Pair Apple Watch, Wear OS, Fitbit" onClick={() => navigate({ to: "/devices" })} />
        <Row icon={Bell} title="My medicines" subtitle="Manage all reminders" onClick={() => navigate({ to: "/meds" })} />
        <Row icon={Download} title={exporting ? "Exporting…" : "Export history"} subtitle="Professional CSV with adherence summary" onClick={exportHistory} />
      </Section>

      <Section title="Help & safety">
        <Row icon={Stethoscope} title="Safety guidelines" subtitle="What MediMind can and can't do" onClick={() => setSheet("safety")} />
        <Row icon={Shield} title="Privacy" subtitle="How we protect your data" onClick={() => setSheet("privacy")} />
        <Row icon={HelpCircle} title="Help & support" subtitle="FAQs, troubleshooting, contact us" onClick={() => setSheet("help")} />
        {dismissed && (
          <Row
            icon={RotateCcw}
            title="Show disclaimer again"
            subtitle="Re-enable the safety banner"
            onClick={() => { reset(); toast.success("Disclaimer re-enabled"); }}
          />
        )}
      </Section>

      <div className="mt-6">
        <DisclaimerCard />
      </div>

      <button onClick={signOut} className="mt-6 w-full h-12 rounded-2xl border border-border bg-card text-sm font-semibold flex items-center justify-center gap-2 text-coral active:scale-95">
        <LogOut className="size-4" /> Sign out
      </button>

      <p className="text-center text-xs text-muted-foreground mt-6 mb-4">MediMind · v1.4</p>

      <Sheet open={!!sheet} onOpenChange={(o) => !o && setSheet(null)}>
        <SheetContent side="bottom" className="rounded-t-3xl max-h-[85vh] overflow-y-auto">
          <SheetHeader className="text-left">
            <SheetTitle className="font-display text-xl">
              {sheet === "safety" ? "Safety guidelines" : sheet === "privacy" ? "Privacy & your data" : "Help & support"}
            </SheetTitle>
            <SheetDescription>
              {sheet === "safety" && "Read this before relying on MediMind for clinical decisions."}
              {sheet === "privacy" && "What we collect, where it lives, and who can see it."}
              {sheet === "help" && "Quick answers to the questions we hear most."}
            </SheetDescription>
          </SheetHeader>
          <div className="mt-4 space-y-4 text-sm text-muted-foreground leading-relaxed">
            {sheet === "safety" && <SafetyContent />}
            {sheet === "privacy" && <PrivacyContent />}
            {sheet === "help" && <HelpContent />}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}

function SafetyContent() {
  return (
    <>
      <Block title="Not a medical device">
        MediMind is a personal medication tracker. It does <strong className="text-foreground">not</strong> diagnose, prescribe, or replace advice from a licensed clinician. The drug information we show is summarised by AI from publicly available sources and may be incomplete or out of date.
      </Block>
      <Block title="Always verify the label">
        Photo scans rely on AI vision and can misread handwriting, blurry text, or unusual abbreviations. Before you save a new reminder, double-check the medicine name, dose, frequency and duration against your bottle, blister pack or pharmacy printout.
      </Block>
      <Block title="Never self-adjust without a clinician">
        Don't start, stop, double-up, or change the timing of a prescription based on what you read here. Talk to the prescribing doctor or your pharmacist first — especially for blood thinners, insulin, antibiotics, cardiac drugs, mental-health meds and anything taken during pregnancy.
      </Block>
      <Block title="Allergies & interactions">
        We surface common interactions and side effects, but the list is not exhaustive. Tell your doctor about every prescription, OTC drug, supplement and herb you take. Watch for: trouble breathing, swelling of the face or throat, severe rash, chest pain, fainting, confusion, or unusual bleeding.
      </Block>
      <Block title="Emergencies">
        If you suspect an overdose, allergic reaction, or any life-threatening symptom, call your local emergency number immediately. In the US: <strong className="text-foreground">911</strong>. Poison control (US): <strong className="text-foreground">1-800-222-1222</strong>.
      </Block>
      <Block title="Children & vulnerable adults">
        Keep all medications locked away. Do not rely solely on phone reminders for someone who cannot manage their own meds — a caregiver should supervise.
      </Block>
    </>
  );
}

function PrivacyContent() {
  return (
    <>
      <Block title="What we store">
        Your medicines, schedules, adherence log, doctor contacts and appointments live in your private account, secured by your email + password. Personal notes and scan history stay on your device only.
      </Block>
      <Block title="Photos you scan">
        Images are sent to our AI provider for one-shot analysis and are <strong className="text-foreground">not retained</strong> on our servers afterwards. Only the extracted text — medicine name, dose, etc. — is saved, and only if you tap save.
      </Block>
      <Block title="Doctor numbers">
        Phone numbers you save are visible only under <em>Profile → My doctor contacts</em>. They are never shown on the home screen, exported in plaintext to other users, or shared with any third party.
      </Block>
      <Block title="What we never do">
        We do not sell your data, run ads, share it with insurers, employers or advertisers, or use your medical history to train public AI models.
      </Block>
      <Block title="Your controls">
        Export everything any time from <em>Settings → Export history</em>. Delete your account by signing out and emailing privacy@medimind.app — we'll wipe your records within 30 days.
      </Block>
    </>
  );
}

function HelpContent() {
  return (
    <>
      <Block title="Reminders aren't showing">
        Open <em>Devices & smartwatch</em> and tap <strong className="text-foreground">Enable notifications</strong>. On iPhone, also check Settings → Notifications → your browser → Allow. If you use Do Not Disturb, add MediMind to your allow list.
      </Block>
      <Block title="My smartwatch isn't buzzing">
        Web push reminders mirror to your watch automatically if the watch is paired with your phone. Open <em>Devices</em> for step-by-step pairing tips for Apple Watch, Wear OS and Fitbit.
      </Block>
      <Block title="The scanner returned 'Unknown'">
        Try better lighting, hold the camera steady, and fill the frame with the label. If it still fails, switch to the <strong className="text-foreground">Manual</strong> tab and type the name — you'll get the same drug info.
      </Block>
      <Block title="A reminder time is wrong">
        Open the medicine and tap the pencil icon. You can add, remove or change any time, switch the pill colour, or rename the drug.
      </Block>
      <Block title="I want to track for someone else">
        Sign out and create a separate account for each person. Profiles never share data.
      </Block>
      <Block title="Still stuck?">
        Email <strong className="text-foreground">support@medimind.app</strong> with a short description and a screenshot — we usually reply within one business day.
      </Block>
    </>
  );
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card/60 p-4">
      <p className="font-bold text-foreground text-sm mb-1.5">{title}</p>
      <p className="text-sm">{children}</p>
    </div>
  );
}

function csvEsc(v: string): string {
  if (v == null) return "";
  const s = String(v);
  if (s.includes(",") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-6">
      <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 px-1">{title}</h2>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function ThemeBtn({ active, onClick, icon: Icon, label }: { active: boolean; onClick: () => void; icon: any; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`h-14 rounded-xl flex flex-col items-center justify-center gap-1 text-[11px] font-semibold transition-all active:scale-95 ${
        active ? "text-primary-foreground" : "text-muted-foreground hover:bg-muted"
      }`}
      style={active ? { background: "var(--gradient-primary)" } : {}}
    >
      <Icon className="size-4" />
      {label}
    </button>
  );
}

function Row({ icon: Icon, title, subtitle, onClick, accent }: { icon: any; title: string; subtitle: string; onClick?: () => void; accent?: boolean }) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left rounded-2xl bg-card border border-border p-3.5 flex items-center gap-3 hover:bg-muted/30 transition-colors active:scale-[0.99]"
      style={{ boxShadow: "var(--shadow-soft)" }}
    >
      <div className={`size-10 rounded-xl flex items-center justify-center shrink-0 ${accent ? "" : "bg-accent"}`}
        style={accent ? { background: "var(--gradient-sunrise)" } : {}}>
        <Icon className={`size-4 ${accent ? "text-white" : "text-primary"}`} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-sm">{title}</p>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </div>
      <ChevronRight className="size-4 text-muted-foreground" />
    </button>
  );
}
