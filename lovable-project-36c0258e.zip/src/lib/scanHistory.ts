// localStorage-backed scan history (lightweight, no DB needed)
export type ScanHistoryItem = {
  id: string;
  mode: "identify" | "rx" | "manual";
  at: string;
  name: string;
  summary: string;
  thumb?: string; // small data URL for preview
  data: any; // full result payload
};

const KEY = "medimind-scan-history";
const MAX = 30;

export function getScanHistory(): ScanHistoryItem[] {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; }
}

export function addScanHistory(item: Omit<ScanHistoryItem, "id" | "at">) {
  const all = getScanHistory();
  all.unshift({ ...item, id: crypto.randomUUID(), at: new Date().toISOString() });
  localStorage.setItem(KEY, JSON.stringify(all.slice(0, MAX)));
}

export function removeScanHistory(id: string) {
  localStorage.setItem(KEY, JSON.stringify(getScanHistory().filter((i) => i.id !== id)));
}

export function clearScanHistory() {
  localStorage.removeItem(KEY);
}

export function getScanItem(id: string): ScanHistoryItem | undefined {
  return getScanHistory().find((i) => i.id === id);
}
