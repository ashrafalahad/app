import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export type Doctor = {
  id: string;
  name: string;
  specialty: string | null;
  phone: string | null;
  notes: string | null;
};

export function useDoctors() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const key = ["doctors", user?.id];

  const query = useQuery({
    queryKey: key,
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("doctors").select("id,name,specialty,phone,notes")
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data as Doctor[];
    },
  });

  const upsert = useMutation({
    mutationFn: async (d: Partial<Doctor> & { id?: string }) => {
      if (!user) throw new Error("Not signed in");
      if (d.id) {
        const { error } = await supabase.from("doctors").update({
          name: d.name, specialty: d.specialty, phone: d.phone, notes: d.notes,
        }).eq("id", d.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("doctors").insert({
          user_id: user.id, name: d.name ?? "", specialty: d.specialty ?? null,
          phone: d.phone ?? null, notes: d.notes ?? null,
        });
        if (error) throw error;
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: key }),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("doctors").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: key }),
  });

  return { ...query, upsert, remove };
}
