import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export type DoctorContact = { doctor_name: string | null; doctor_phone: string | null };

export function useDoctorContact() {
  const { user } = useAuth();
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: ["doctor-contact", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("doctor_name,doctor_phone")
        .eq("id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return (data ?? { doctor_name: null, doctor_phone: null }) as DoctorContact;
    },
  });

  const save = useMutation({
    mutationFn: async (v: DoctorContact) => {
      if (!user) throw new Error("Not signed in");
      const { error } = await supabase
        .from("profiles")
        .update({ doctor_name: v.doctor_name, doctor_phone: v.doctor_phone })
        .eq("id", user.id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["doctor-contact", user?.id] }),
  });

  return { ...query, save };
}
