import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { chatJSON } from "./ai.server";

// ---------- Prescription scan ----------
const ScanInput = z.object({ imageBase64: z.string().min(50) });

export const scanPrescription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ScanInput.parse(d))
  .handler(async ({ data }) => {
    const dataUrl = data.imageBase64.startsWith("data:")
      ? data.imageBase64
      : `data:image/jpeg;base64,${data.imageBase64}`;

    const result = await chatJSON({
      model: "google/gemini-2.5-flash",
      messages: [
        {
          role: "system",
          content:
            "You are a clinical assistant that reads prescription images and extracts structured medication data. Always return strict JSON.",
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Extract every medication on this prescription. For each, infer dosage, frequency (in plain English: "once daily", "twice daily", "every 8 hours", etc.), duration, and special instructions (e.g. "with food"). Expand abbreviations: BID=twice daily, TID=three times daily, QID=four times daily, QD=once daily, QHS=at bedtime, PRN=as needed.

Return ONLY JSON of the form:
{
  "medicines": [
    { "name": "string", "dosage": "string", "frequency": "string", "duration": "string", "instructions": "string", "confidence": "high|medium|low" }
  ],
  "needs_review": boolean,
  "warnings": ["string"]
}

If you cannot read the image, return {"medicines":[], "needs_review": true, "warnings":["Unable to read prescription clearly"]}.`,
            },
            { type: "image_url", image_url: { url: dataUrl } },
          ],
        },
      ],
    });

    return result as {
      medicines: Array<{
        name: string;
        dosage: string;
        frequency: string;
        duration: string;
        instructions: string;
        confidence: "high" | "medium" | "low";
      }>;
      needs_review: boolean;
      warnings?: string[];
    };
  });

// ---------- Drug info (cached) ----------
const InfoInput = z.object({ name: z.string().min(1).max(120) });

// Returns cached drug info ONLY (no AI call). Used to show data without auto-fetching.
export const getCachedDrugInfo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => InfoInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const key = data.name.trim().toLowerCase();
    const { data: cached } = await supabase
      .from("drug_info_cache").select("*").eq("drug_key", key).maybeSingle();
    return cached ?? null;
  });

export const getDrugInfo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => InfoInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const key = data.name.trim().toLowerCase();

    const { data: cached } = await supabase
      .from("drug_info_cache")
      .select("*")
      .eq("drug_key", key)
      .maybeSingle();

    if (cached) return cached;

    const ai = await chatJSON({
      model: "google/gemini-2.5-flash",
      messages: [
        {
          role: "system",
          content:
            "You are a clinical pharmacist. Return strict JSON with neutral, patient-friendly drug information. Never diagnose. If unsure, write 'Unknown — consult your pharmacist'.",
        },
        {
          role: "user",
          content: `Drug: "${data.name}". Return JSON:
{
  "what_for": "one short sentence",
  "how_it_works": "one short sentence",
  "common_side_effects": ["string", "string", "string"],
  "serious_side_effects": ["string"],
  "missed_dose": "one sentence",
  "interactions": ["string"],
  "pregnancy_warning": "one sentence"
}`,
        },
      ],
    });

    const row = {
      drug_key: key,
      drug_name: data.name,
      what_for: ai.what_for ?? null,
      how_it_works: ai.how_it_works ?? null,
      common_side_effects: ai.common_side_effects ?? [],
      serious_side_effects: ai.serious_side_effects ?? [],
      missed_dose: ai.missed_dose ?? null,
      interactions: ai.interactions ?? [],
      pregnancy_warning: ai.pregnancy_warning ?? null,
      source: "AI_generated",
    };

    // Best-effort cache (ignore conflict)
    await supabase.from("drug_info_cache").upsert(row, { onConflict: "drug_key" });
    return row;
  });

// ---------- Identify any medicine from a photo (pill, box, bottle, label) ----------
const IdInput = z.object({ imageBase64: z.string().min(50) });

export const identifyMedicine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => IdInput.parse(d))
  .handler(async ({ data }) => {
    const dataUrl = data.imageBase64.startsWith("data:")
      ? data.imageBase64
      : `data:image/jpeg;base64,${data.imageBase64}`;

    const ai = await chatJSON({
      model: "google/gemini-2.5-flash",
      messages: [
        {
          role: "system",
          content:
            "You are a clinical pharmacist. Identify a medicine from a photo (pill, blister pack, box, bottle, or label). Return strict JSON. Never diagnose.",
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Identify the medicine in this photo. If you cannot identify with reasonable confidence, set confidence to "low" and explain why in 'note'. Return ONLY JSON:
{
  "name": "Brand or generic name (best guess)",
  "generic_name": "Active ingredient",
  "strength": "e.g. 500 mg, 10 mg/5 mL",
  "form": "tablet | capsule | syrup | injection | cream | other",
  "what_for": "one short sentence — what it treats",
  "how_it_works": "one short sentence",
  "common_side_effects": ["string","string","string"],
  "serious_side_effects": ["string"],
  "interactions": ["string"],
  "missed_dose": "one sentence",
  "pregnancy_warning": "one sentence",
  "confidence": "high|medium|low",
  "note": "string"
}`,
            },
            { type: "image_url", image_url: { url: dataUrl } },
          ],
        },
      ],
    });

    return ai as {
      name: string; generic_name?: string; strength?: string; form?: string;
      what_for?: string; how_it_works?: string;
      common_side_effects?: string[]; serious_side_effects?: string[];
      interactions?: string[]; missed_dose?: string; pregnancy_warning?: string;
      confidence: "high" | "medium" | "low"; note?: string;
    };
  });
