// Server-only Lovable AI Gateway helper (raw fetch — keeps Worker bundle small).
const BASE = "https://ai.gateway.lovable.dev/v1";

type ChatMsg = { role: "system" | "user" | "assistant"; content: any };

export async function chatJSON(opts: {
  model?: string;
  messages: ChatMsg[];
  temperature?: number;
}) {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  const res = await fetch(`${BASE}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": key,
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model: opts.model ?? "google/gemini-2.5-flash",
      messages: opts.messages,
      temperature: opts.temperature ?? 0.2,
      response_format: { type: "json_object" },
    }),
  });
  if (res.status === 429) throw new Error("AI rate limit. Please try again in a moment.");
  if (res.status === 402) throw new Error("AI credits exhausted. Add credits in Workspace Settings.");
  if (!res.ok) throw new Error(`AI gateway error ${res.status}: ${await res.text()}`);
  const json = await res.json();
  const content = json.choices?.[0]?.message?.content ?? "{}";
  try {
    return JSON.parse(content);
  } catch {
    // sometimes wrapped in code fences
    const m = content.match(/\{[\s\S]*\}/);
    return m ? JSON.parse(m[0]) : {};
  }
}
