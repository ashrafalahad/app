import { useEffect, useState } from "react";

const KEY = "medimind-disclaimer-dismissed";

export function useDisclaimerDismissed() {
  const [dismissed, setDismissed] = useState(false);
  useEffect(() => {
    setDismissed(localStorage.getItem(KEY) === "1");
  }, []);
  const dismiss = () => {
    localStorage.setItem(KEY, "1");
    setDismissed(true);
  };
  const reset = () => {
    localStorage.removeItem(KEY);
    setDismissed(false);
  };
  return { dismissed, dismiss, reset };
}
