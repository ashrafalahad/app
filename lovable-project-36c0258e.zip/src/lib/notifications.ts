// Lightweight notifications + paired-device prefs (stored in localStorage).
// Browser notifications mirror to paired Apple Watch / Wear OS via the phone.

const PERM_KEY = "medimind-notif-enabled";
const DEVICES_KEY = "medimind-paired-devices";
const SOUND_KEY = "medimind-notif-sound";

export type PairedDevice = {
  id: string;
  name: string;
  type: "apple-watch" | "wear-os" | "fitbit" | "phone";
  pairedAt: string;
};

export function notifPermission(): NotificationPermission {
  if (typeof Notification === "undefined") return "denied";
  return Notification.permission;
}

export async function requestNotif(): Promise<boolean> {
  if (typeof Notification === "undefined") return false;
  if (Notification.permission === "granted") {
    localStorage.setItem(PERM_KEY, "1");
    return true;
  }
  const p = await Notification.requestPermission();
  const ok = p === "granted";
  localStorage.setItem(PERM_KEY, ok ? "1" : "0");
  return ok;
}

export function notifEnabled(): boolean {
  return notifPermission() === "granted" && localStorage.getItem(PERM_KEY) !== "0";
}

export function setNotifEnabled(v: boolean) {
  localStorage.setItem(PERM_KEY, v ? "1" : "0");
}

export function showTest(title = "MediMind", body = "Test reminder — your watch should buzz too.") {
  if (notifPermission() !== "granted") return;
  try {
    new Notification(title, { body, icon: "/favicon.ico", tag: "medimind-test" });
  } catch {}
}

export function getDevices(): PairedDevice[] {
  try {
    return JSON.parse(localStorage.getItem(DEVICES_KEY) || "[]");
  } catch {
    return [];
  }
}

export function addDevice(d: Omit<PairedDevice, "id" | "pairedAt">): PairedDevice {
  const device: PairedDevice = {
    ...d,
    id: crypto.randomUUID(),
    pairedAt: new Date().toISOString(),
  };
  const all = [...getDevices(), device];
  localStorage.setItem(DEVICES_KEY, JSON.stringify(all));
  return device;
}

export function removeDevice(id: string) {
  const all = getDevices().filter((d) => d.id !== id);
  localStorage.setItem(DEVICES_KEY, JSON.stringify(all));
}

export function getSound(): boolean {
  return localStorage.getItem(SOUND_KEY) !== "0";
}
export function setSound(v: boolean) {
  localStorage.setItem(SOUND_KEY, v ? "1" : "0");
}
