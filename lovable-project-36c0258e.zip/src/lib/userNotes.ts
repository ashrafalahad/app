// Personal notes (general — not per medicine).
import { useEffect, useState, useCallback } from "react";

export type UserNote = { id: string; title: string; body: string; updatedAt: string };
const KEY = "medimind-notes";

function read(): UserNote[] {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; }
}
function write(v: UserNote[]) { localStorage.setItem(KEY, JSON.stringify(v)); }

export function useUserNotes() {
  const [items, setItems] = useState<UserNote[]>([]);
  useEffect(() => { setItems(read()); }, []);

  const save = useCallback((n: Omit<UserNote, "id" | "updatedAt"> & { id?: string }) => {
    const all = read();
    const updatedAt = new Date().toISOString();
    if (n.id) {
      const next = all.map((x) => x.id === n.id ? { ...x, title: n.title, body: n.body, updatedAt } : x);
      write(next); setItems(next);
    } else {
      const next = [{ id: crypto.randomUUID(), title: n.title, body: n.body, updatedAt }, ...all];
      write(next); setItems(next);
    }
  }, []);

  const remove = useCallback((id: string) => {
    const next = read().filter((x) => x.id !== id);
    write(next); setItems(next);
  }, []);

  return { items, save, remove };
}
