// localStorage-backed appointments with a simple in-app reminder check.
import { useEffect, useState, useCallback } from "react";

export type Appointment = {
  id: string;
  doctor: string;
  specialty?: string;
  location?: string;
  notes?: string;
  at: string; // ISO date-time
  reminded?: boolean;
};

const KEY = "medimind-appointments";

function read(): Appointment[] {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; }
}
function write(v: Appointment[]) { localStorage.setItem(KEY, JSON.stringify(v)); }

export function useAppointments() {
  const [items, setItems] = useState<Appointment[]>([]);

  useEffect(() => { setItems(read()); }, []);

  const refresh = useCallback(() => setItems(read()), []);

  const add = useCallback((a: Omit<Appointment, "id">) => {
    const all = read();
    all.push({ ...a, id: crypto.randomUUID() });
    all.sort((x, y) => x.at.localeCompare(y.at));
    write(all);
    setItems(all);
  }, []);

  const update = useCallback((id: string, patch: Partial<Appointment>) => {
    const all = read().map((x) => x.id === id ? { ...x, ...patch } : x);
    all.sort((x, y) => x.at.localeCompare(y.at));
    write(all);
    setItems(all);
  }, []);

  const remove = useCallback((id: string) => {
    const all = read().filter((x) => x.id !== id);
    write(all);
    setItems(all);
  }, []);

  return { items, add, update, remove, refresh };
}

export function upcomingAppointments(): Appointment[] {
  const now = Date.now();
  return read().filter((a) => new Date(a.at).getTime() > now);
}
