import { Pill, Tablets, Syringe, FlaskConical, Droplet, Wind, Package, Leaf, Atom, MoreHorizontal, LucideIcon } from "lucide-react";

export const DEFAULT_PILL_COLOR = "#5dd5b4";

export const PILL_COLORS = [
  "#5dd5b4", "#ff8c66", "#fbbf24", "#a78bfa",
  "#60a5fa", "#f472b6", "#34d399", "#f87171",
];

export function iconForForm(form?: string | null): LucideIcon {
  const f = (form ?? "").toLowerCase();
  if (f.includes("peptide")) return Atom;
  if (f.includes("supplement") || f.includes("vitamin")) return Leaf;
  if (f.includes("inject") || f.includes("syringe")) return Syringe;
  if (f.includes("tablet")) return Tablets;
  if (f.includes("drop") || f.includes("liquid") || f.includes("syrup") || f.includes("solution")) return Droplet;
  if (f.includes("flask") || f.includes("vial")) return FlaskConical;
  if (f.includes("inhal") || f.includes("spray")) return Wind;
  if (f.includes("powder") || f.includes("sachet")) return Package;
  if (f === "other" || f.includes("other")) return MoreHorizontal;
  return Pill;
}

export function readableTextOn(_hex: string): string {
  return "#ffffff";
}
