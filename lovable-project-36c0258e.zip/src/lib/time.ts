// 12-hour time helpers (used everywhere instead of raw HH:mm)
export function to12h(hhmm: string): string {
  if (!hhmm || !hhmm.includes(":")) return hhmm;
  const [hStr, mStr] = hhmm.split(":");
  const h = parseInt(hStr, 10);
  const m = mStr.padStart(2, "0");
  const period = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${m} ${period}`;
}

export function to12hParts(hhmm: string): { h: string; m: string; p: string } {
  if (!hhmm || !hhmm.includes(":")) return { h: "--", m: "--", p: "" };
  const [hStr, mStr] = hhmm.split(":");
  const h = parseInt(hStr, 10);
  const period = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return { h: String(h12), m: mStr.padStart(2, "0"), p: period };
}
