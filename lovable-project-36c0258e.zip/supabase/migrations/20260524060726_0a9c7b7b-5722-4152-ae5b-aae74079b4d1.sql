
ALTER TABLE public.medicines
  ADD COLUMN IF NOT EXISTS pill_color text,
  ADD COLUMN IF NOT EXISTS notes text;

CREATE TABLE IF NOT EXISTS public.doctors (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  name text not null,
  specialty text,
  phone text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

ALTER TABLE public.doctors ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS doctors_select_own ON public.doctors;
DROP POLICY IF EXISTS doctors_insert_own ON public.doctors;
DROP POLICY IF EXISTS doctors_update_own ON public.doctors;
DROP POLICY IF EXISTS doctors_delete_own ON public.doctors;

CREATE POLICY doctors_select_own ON public.doctors FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY doctors_insert_own ON public.doctors FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY doctors_update_own ON public.doctors FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY doctors_delete_own ON public.doctors FOR DELETE USING (auth.uid() = user_id);

DROP TRIGGER IF EXISTS doctors_set_updated_at ON public.doctors;
CREATE TRIGGER doctors_set_updated_at
  BEFORE UPDATE ON public.doctors
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- Backfill from existing profiles.doctor_name/doctor_phone (best-effort)
INSERT INTO public.doctors (user_id, name, phone)
SELECT id, doctor_name, doctor_phone
FROM public.profiles
WHERE doctor_name IS NOT NULL AND doctor_name <> ''
  AND NOT EXISTS (SELECT 1 FROM public.doctors d WHERE d.user_id = public.profiles.id);
