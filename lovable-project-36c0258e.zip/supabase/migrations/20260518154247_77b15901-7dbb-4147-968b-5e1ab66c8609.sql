
-- profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  disclaimer_accepted_at timestamptz,
  pharmacy_contact text,
  quiet_hours_start time,
  quiet_hours_end time,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);

-- auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)));
  return new;
end;
$$;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- medicines
create table public.medicines (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  dosage text not null,
  frequency_type text not null default 'daily',
  times text[] not null default '{}',
  days_of_week int[],
  start_date date not null default current_date,
  end_date date,
  instructions text,
  prescription_image_url text,
  drug_key text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.medicines enable row level security;
create policy "medicines_select_own" on public.medicines for select using (auth.uid() = user_id);
create policy "medicines_insert_own" on public.medicines for insert with check (auth.uid() = user_id);
create policy "medicines_update_own" on public.medicines for update using (auth.uid() = user_id);
create policy "medicines_delete_own" on public.medicines for delete using (auth.uid() = user_id);
create index medicines_user_id_idx on public.medicines(user_id);

-- adherence_logs
create table public.adherence_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  medicine_id uuid not null references public.medicines(id) on delete cascade,
  scheduled_for timestamptz not null,
  taken_at timestamptz,
  status text not null check (status in ('taken','skipped','snoozed')),
  skip_reason text,
  created_at timestamptz not null default now()
);
alter table public.adherence_logs enable row level security;
create policy "logs_select_own" on public.adherence_logs for select using (auth.uid() = user_id);
create policy "logs_insert_own" on public.adherence_logs for insert with check (auth.uid() = user_id);
create policy "logs_update_own" on public.adherence_logs for update using (auth.uid() = user_id);
create policy "logs_delete_own" on public.adherence_logs for delete using (auth.uid() = user_id);
create unique index logs_unique_dose on public.adherence_logs(user_id, medicine_id, scheduled_for);
create index logs_user_scheduled_idx on public.adherence_logs(user_id, scheduled_for);

-- drug_info_cache (shared, public read for signed-in)
create table public.drug_info_cache (
  drug_key text primary key,
  drug_name text not null,
  what_for text,
  how_it_works text,
  common_side_effects text[],
  serious_side_effects text[],
  missed_dose text,
  interactions text[],
  pregnancy_warning text,
  source text default 'AI_generated',
  updated_at timestamptz not null default now()
);
alter table public.drug_info_cache enable row level security;
create policy "drug_info_read_all" on public.drug_info_cache for select to authenticated using (true);

-- updated_at trigger
create or replace function public.tg_set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;
create trigger medicines_updated_at before update on public.medicines
  for each row execute function public.tg_set_updated_at();
create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.tg_set_updated_at();
