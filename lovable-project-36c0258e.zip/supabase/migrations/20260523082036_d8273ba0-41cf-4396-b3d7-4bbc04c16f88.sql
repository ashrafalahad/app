
ALTER TABLE public.medicines
  ADD COLUMN IF NOT EXISTS form text,
  ADD COLUMN IF NOT EXISTS reason text;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS doctor_name text,
  ADD COLUMN IF NOT EXISTS doctor_phone text;
