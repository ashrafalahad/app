CREATE INDEX IF NOT EXISTS idx_adherence_logs_user_scheduled
  ON public.adherence_logs(user_id, scheduled_for);

CREATE INDEX IF NOT EXISTS idx_adherence_logs_medicine
  ON public.adherence_logs(medicine_id);

DO $$ BEGIN
  ALTER TABLE public.adherence_logs
    ADD CONSTRAINT adherence_logs_user_med_sched_unique
    UNIQUE (user_id, medicine_id, scheduled_for);
EXCEPTION WHEN duplicate_table OR duplicate_object THEN NULL; END $$;